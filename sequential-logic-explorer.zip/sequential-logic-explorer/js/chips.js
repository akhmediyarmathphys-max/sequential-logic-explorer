/* chips.js — reference HDL sources and blank skeletons (Nand2Tetris Project 3 style). */
(function (g) {
  'use strict';

  const regLines = Array.from({ length: 16 }, (_, i) =>
    `    Bit(in=in[${i}], load=load, out=out[${i}]);`).join('\n');

  const ram8Regs = Array.from({ length: 8 }, (_, i) =>
    `    Register(in=in, load=l${i}, out=r${i});`).join('\n');

  const ram64Parts = Array.from({ length: 8 }, (_, i) =>
    `    RAM8(in=in, load=l${i}, address=address[0..2], out=r${i});`).join('\n');

  const HEAD = {
    DFF: `// DFF.hdl  —  Data Flip-Flop (the primitive of all memory)
//   out(t) = in(t - 1)
// It needs a feedback loop that is not broken by a clock, which
// this HDL does not allow, so the simulator provides it built-in.
CHIP DFF {
    IN  in;
    OUT out;
`,
    Bit: `// Bit.hdl  —  1-bit register
//   if load(t) == 1 then out(t+1) = in(t)
//                   else out(t+1) = out(t)
CHIP Bit {
    IN  in, load;
    OUT out;
`,
    Register: `// Register.hdl  —  16-bit register
//   if load(t) == 1 then out(t+1) = in(t)
//                   else out(t+1) = out(t)
CHIP Register {
    IN  in[16], load;
    OUT out[16];
`,
    RAM8: `// RAM8.hdl  —  memory of 8 registers, 16 bits each
//   out(t) = RAM[address(t)]          (reading is instant)
//   if load(t) then RAM[address(t)](t+1) = in(t)
CHIP RAM8 {
    IN  in[16], load, address[3];
    OUT out[16];
`,
    PC: `// PC.hdl  —  16-bit program counter
//   if      reset(t): out(t+1) = 0
//   else if load(t):  out(t+1) = in(t)
//   else if inc(t):   out(t+1) = out(t) + 1
//   else              out(t+1) = out(t)
CHIP PC {
    IN  in[16], load, inc, reset;
    OUT out[16];
`,
    RAM64: `// RAM64.hdl  —  memory of 64 registers (bonus: built from 8 x RAM8)
//   address[3..5] picks one RAM8, address[0..2] picks the register inside it
CHIP RAM64 {
    IN  in[16], load, address[6];
    OUT out[16];
`,
  };

  const BODY = {
    DFF: `
    BUILTIN DFF;
    CLOCKED in;
}
`,
    Bit: `
    PARTS:
    // load chooses: keep the old value (a) or take the new one (b)
    Mux(a=dffOut, b=in, sel=load, out=muxOut);
    // the DFF remembers it for one cycle; its output loops back to the Mux
    DFF(in=muxOut, out=dffOut, out=out);
}
`,
    Register: `
    PARTS:
    // 16 independent Bits that share the same load signal
${regLines}
}
`,
    RAM8: `
    PARTS:
    // WRITE path: deliver load only to the selected register
    DMux8Way(in=load, sel=address, a=l0, b=l1, c=l2, d=l3, e=l4, f=l5, g=l6, h=l7);
${ram8Regs}
    // READ path: route the selected register to out
    Mux8Way16(a=r0, b=r1, c=r2, d=r3, e=r4, f=r5, g=r6, h=r7, sel=address, out=out);
}
`,
    PC: `
    PARTS:
    Inc16(in=feedback, out=plusOne);
    // lowest priority first; the Mux closest to the Register wins
    Mux16(a=feedback, b=plusOne, sel=inc, out=afterInc);
    Mux16(a=afterInc, b=in, sel=load, out=afterLoad);
    Mux16(a=afterLoad, b=false, sel=reset, out=next);
    // load=true: the register is rewritten every cycle
    Register(in=next, load=true, out=feedback, out=out);
}
`,
    RAM64: `
    PARTS:
    DMux8Way(in=load, sel=address[3..5], a=l0, b=l1, c=l2, d=l3, e=l4, f=l5, g=l6, h=l7);
${ram64Parts}
    Mux8Way16(a=r0, b=r1, c=r2, d=r3, e=r4, f=r5, g=r6, h=r7, sel=address[3..5], out=out);
}
`,
  };

  const SRC = {}, SKEL = {};
  Object.keys(HEAD).forEach((k) => {
    SRC[k] = HEAD[k] + BODY[k];
    SKEL[k] = k === 'DFF' ? SRC[k] : HEAD[k] + '\n    PARTS:\n    // Put your code here:\n\n}\n';
  });

  g.CHIP_SRC = SRC;
  g.CHIP_SKELETON = SKEL;
})(typeof window !== 'undefined' ? window : globalThis);
