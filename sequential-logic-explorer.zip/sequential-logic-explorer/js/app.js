/* app.js — interactive pages for the Sequential Logic Explorer */
(function () {
  'use strict';
  const H = window.HDL;
  const SRC = window.CHIP_SRC;
  const SKEL = window.CHIP_SKELETON;

  /* ================================================================ *
   *  Utilities                                                        *
   * ================================================================ */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const sleep = (ms) => new Promise((res) => setTimeout(res, ms));
  const mask = (w) => (1 << w) - 1;
  const s16 = (v) => (v & 0x8000 ? v - 0x10000 : v);
  const bin = (v, w) => (v >>> 0).toString(2).padStart(w, '0').slice(-w);
  const hex = (v) => '0x' + (v & 0xffff).toString(16).toUpperCase().padStart(4, '0');
  const fmt = (v, w) => (w === 1 ? String(v & 1) : w >= 16 ? String(s16(v)) : String(v));
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const popcount = (v) => { let n = 0; while (v) { n += v & 1; v >>>= 1; } return n; };
  const b1 = (v) => `<b class="v${v ? 1 : 0}">${v ? 1 : 0}</b>`;
  const n16 = (v) => `<span class="vb16">${s16(v)}</span>`;
  function html(str) {
    const t = document.createElement('template');
    t.innerHTML = str.trim();
    return t.content.firstElementChild;
  }
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage unavailable */ } },
  };
  function restartAnim(el, cls) {
    if (!el) return;
    el.classList.remove(cls);
    void el.getBoundingClientRect();
    el.classList.add(cls);
  }
  const NS = 'http://www.w3.org/2000/svg';
  function pulseAlong(svg, d, dur) {
    if (!svg) return;
    const c = document.createElementNS(NS, 'circle');
    c.setAttribute('r', '6');
    c.setAttribute('class', 'pulse-dot');
    c.setAttribute('cx', '-50');
    const am = document.createElementNS(NS, 'animateMotion');
    am.setAttribute('dur', dur + 'ms');
    am.setAttribute('path', d);
    am.setAttribute('fill', 'freeze');
    am.setAttribute('begin', 'indefinite');
    c.appendChild(am);
    svg.appendChild(c);
    c.setAttribute('cx', '0');
    try { am.beginElement(); } catch (e) { /* SMIL unsupported */ }
    setTimeout(() => c.remove(), dur + 80);
  }

  /* ================================================================ *
   *  Theme + tabs                                                     *
   * ================================================================ */
  const root = document.documentElement;
  const prefersLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
  root.dataset.theme = store.get('sl-theme', prefersLight ? 'light' : 'dark');
  $('#themeBtn').addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    store.set('sl-theme', root.dataset.theme);
  });

  const demos = {};
  let currentTab = 'overview';
  function showTab(id, scroll) {
    if (!$(`.panel[data-tab="${id}"]`)) id = 'overview';
    currentTab = id;
    $$('.panel').forEach((p) => p.classList.toggle('active', p.dataset.tab === id));
    $$('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === id));
    Object.values(demos).forEach((d) => d.stopAuto());
    if (location.hash !== '#' + id) { try { history.replaceState(null, '', '#' + id); } catch (e) { location.hash = id; } }
    if (scroll !== false) window.scrollTo({ top: 0 });
    if (demos[id]) demos[id].refresh(false);
    if (id === 'lab') lab.ensure();
    const btn = $(`.tab[data-tab="${id}"]`);
    if (btn && btn.scrollIntoView) btn.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }
  $$('.tab').forEach((t) => t.addEventListener('click', () => showTab(t.dataset.tab)));
  $$('[data-go]').forEach((n) => n.addEventListener('click', () => showTab(n.dataset.go)));
  window.addEventListener('hashchange', () => showTab(location.hash.slice(1), false));

  /* ================================================================ *
   *  Pinout diagrams                                                  *
   * ================================================================ */
  const SEQ = new Set(['DFF', 'Bit', 'Register', 'RAM8', 'RAM64', 'PC']);
  function pinoutSVG(def) {
    const ins = def.inputs, outs = def.outputs;
    const rows = Math.max(ins.length, outs.length, 2);
    const bx = 125, bw = 110, by = 12, bh = rows * 30 + 10;
    const W = 360, Ht = by + bh + 14;
    let s = `<svg viewBox="0 0 ${W} ${Ht}" role="img" aria-label="${def.name} interface">`;
    const side = (list, left) => list.forEach((p, i) => {
      const y = by + (bh / list.length) * (i + 0.5);
      const cls = p.width > 1 ? 'pbus' : 'pline';
      const label = p.width > 1 ? `${p.name}[${p.width}]` : p.name;
      if (left) {
        s += `<line class="${cls}" x1="${bx - 34}" y1="${y}" x2="${bx}" y2="${y}"/>`;
        s += `<text class="plabel" x="${bx - 40}" y="${y + 4}" text-anchor="end">${label}</text>`;
      } else {
        s += `<line class="${cls}" x1="${bx + bw}" y1="${y}" x2="${bx + bw + 34}" y2="${y}"/>`;
        s += `<text class="plabel" x="${bx + bw + 40}" y="${y + 4}">${label}</text>`;
      }
    });
    side(ins, true);
    side(outs, false);
    s += `<rect class="pbox" x="${bx}" y="${by}" width="${bw}" height="${bh}" rx="10"/>`;
    s += `<text class="pname" x="${bx + bw / 2}" y="${by + bh / 2 + 4}" text-anchor="middle">${def.name}</text>`;
    if (SEQ.has(def.name)) {
      const cx = bx + bw / 2, yb = by + bh;
      s += `<path class="pclk" d="M${cx - 10} ${yb} L${cx} ${yb - 12} L${cx + 10} ${yb}"/>`;
    }
    return s + '</svg>';
  }
  $$('[data-pinout]').forEach((el) => { el.innerHTML = pinoutSVG(H.BUILTINS[el.dataset.pinout]); });

  /* ================================================================ *
   *  HDL rendering (syntax highlight + live value badges)             *
   * ================================================================ */
  function renderLines(src, marks, errLine) {
    const toks = H.lex(src);
    const lines = [''];
    for (const t of toks) {
      const pieces = src.slice(t.s, t.e).split('\n');
      pieces.forEach((piece, k) => {
        if (k > 0) lines.push('');
        if (piece) lines[lines.length - 1] += t.cls ? `<span class="tk-${t.cls}">${esc(piece)}</span>` : esc(piece);
      });
      if (marks && marks.has(t.e)) lines[lines.length - 1] += `<span class="vb" data-i="${marks.get(t.e)}">·</span>`;
    }
    return lines.map((l, i) =>
      `<div class="cl${errLine === i + 1 ? ' err' : ''}" data-n="${i + 1}">${l || ' '}</div>`).join('');
  }

  class CodeView {
    constructor(host, def, sim) {
      this.sim = sim;
      this.items = [];
      const marks = new Map();
      if (!def.builtin) {
        for (const P of def.parts) {
          for (const c of P.ins.concat(P.outs)) {
            if (c.const !== undefined) continue;
            marks.set(c.src.sigEnd, this.items.length);
            this.items.push({ name: c.sig, lo: c.sLo, w: c.sW, line: c.src.line, prev: null });
          }
        }
      }
      host.innerHTML = `<div class="code">${renderLines(def.source, marks)}</div>`;
      this.box = host.firstElementChild;
      this.badges = $$('.vb', this.box);
      this.lines = $$('.cl', this.box);
    }
    update(flash) {
      const changed = new Set();
      for (const b of this.badges) {
        const it = this.items[+b.dataset.i];
        const v = (this.sim.get(it.name) >>> it.lo) & mask(it.w);
        const txt = fmt(v, it.w);
        if (b.textContent !== txt) {
          b.textContent = txt;
          if (flash && it.prev !== null) { restartAnim(b, 'flash'); changed.add(it.line); }
        }
        it.prev = v;
        b.className = 'vb' + (it.w === 1 ? (v ? ' v1' : '') : ' vbus') + (b.classList.contains('flash') ? ' flash' : '');
        b.title = `${it.name}${it.w < 16 && it.lo ? '' : ''} = ${bin(v, it.w)}${it.w > 1 ? ` (${fmt(v, it.w)})` : ''}`;
      }
      if (flash) {
        this.lines.forEach((l, i) => {
          if (changed.has(i + 1)) {
            l.classList.add('chg');
            setTimeout(() => l.classList.remove('chg'), 900);
          }
        });
      }
    }
  }

  /* ================================================================ *
   *  Timing diagram                                                   *
   * ================================================================ */
  function renderWave(host, traces, entries, t0) {
    const LW = 82, RH = 34, TOP = 26;
    const n = entries.length;
    const avail = (host.clientWidth || 0) - LW - 16;
    const CW = Math.max(56, Math.min(96, avail > 0 ? avail / Math.max(n, 10) : 56));
    const rows = [{ name: 'clk', clk: true }].concat(traces);
    const W = n * CW + 12, Ht = TOP + rows.length * RH + 6;
    let lab = `<svg class="wave wave-labels" width="${LW}" height="${Ht}" viewBox="0 0 ${LW} ${Ht}" aria-hidden="true">`;
    let s = `<svg class="wave" width="${W}" height="${Ht}" viewBox="0 0 ${W} ${Ht}" role="img" aria-label="Timing diagram">`;
    const lx = (n - 1) * CW;
    s += `<rect class="nowbg" x="${lx}" y="${TOP - 6}" width="${CW}" height="${rows.length * RH + 6}" rx="6"/>`;
    for (let i = 0; i <= n; i++) s += `<line class="edge" x1="${i * CW}" y1="${TOP - 6}" x2="${i * CW}" y2="${Ht - 4}"/>`;
    for (let i = 0; i < n; i++) {
      const x = i * CW + CW / 2;
      s += i === n - 1
        ? `<text class="nowt" x="${x}" y="15">t=${t0 + i} now</text>`
        : `<text class="tl" x="${x}" y="15">t=${t0 + i}</text>`;
    }
    rows.forEach((r, ri) => {
      const y0 = TOP + ri * RH, yH = y0 + 5, yL = y0 + RH - 9, ym = (yH + yL) / 2;
      lab += `<text class="wl" x="12" y="${ym + 4}">${esc(r.label || r.name)}</text>`;
      if (r.clk) {
        let d = `M0 ${yL}`;
        for (let i = 0; i < n; i++) d += ` V${yH} H${i * CW + CW / 2} V${yL} H${(i + 1) * CW}`;
        s += `<path class="clkp" d="${d}"/>`;
        return;
      }
      const w = r.w || 1;
      if (w === 1) {
        let d = '', hi = '';
        for (let i = 0; i < n; i++) {
          const v = entries[i][r.name] ? 1 : 0;
          const y = v ? yH : yL, x0 = i * CW, x1 = x0 + CW;
          d += i === 0 ? `M${x0} ${y}` : ` V${y}`;
          d += ` H${x1}`;
          if (v) hi += `<rect class="fill1" x="${x0}" y="${yH}" width="${CW}" height="${yL - yH}"/><line class="sig1" x1="${x0}" y1="${yH}" x2="${x1}" y2="${yH}"/>`;
        }
        s += `<path class="sig0" d="${d}"/>` + hi;
      } else {
        let i = 0;
        while (i < n) {
          const v = entries[i][r.name];
          let j = i;
          while (j + 1 < n && entries[j + 1][r.name] === v) j++;
          const x0 = i * CW + 1.5, x1 = (j + 1) * CW - 1.5, k = 5;
          s += `<polygon class="busp" points="${x0},${ym} ${x0 + k},${yH} ${x1 - k},${yH} ${x1},${ym} ${x1 - k},${yL} ${x0 + k},${yL}"/>`;
          const txt = fmt(v, w);
          const fs = txt.length * 7 > x1 - x0 - 8 ? 9 : 11;
          s += `<text class="bust" x="${(x0 + x1) / 2}" y="${ym}" style="font-size:${fs}px">${txt}</text>`;
          i = j + 1;
        }
      }
    });
    host.innerHTML = `<div class="wave-flex">${lab}</svg><div class="wave-data">${s}</svg></div></div>`;
    const data = host.querySelector('.wave-data');
    data.scrollLeft = data.scrollWidth;
  }

  /* ================================================================ *
   *  Input controls                                                   *
   * ================================================================ */
  function Switch(label, onToggle) {
    const el = html(`<button class="sw" type="button" aria-pressed="false"><span>${esc(label)}</span><span class="track"></span><span class="val">0</span></button>`);
    el.addEventListener('click', () => onToggle(el.classList.contains('on') ? 0 : 1));
    return {
      el,
      set(v) {
        el.classList.toggle('on', !!v);
        el.querySelector('.val').textContent = v ? '1' : '0';
        el.setAttribute('aria-pressed', v ? 'true' : 'false');
      },
    };
  }

  function Word(label, w, onChange) {
    const max = mask(w);
    const el = html(`<div class="word">
      <div class="word-top"><span class="wn">${esc(label)}</span><span class="ww">[${w}]</span>
        <input class="num" type="number" step="1" value="0" aria-label="${esc(label)} value">
        <button class="mini-btn" type="button" data-a="rnd" title="Random value">🎲</button>
        <button class="mini-btn" type="button" data-a="clr" title="Set to 0">0</button></div>
      <div class="bits"></div><div class="readout"></div></div>`);
    const bitsEl = el.querySelector('.bits');
    for (let i = w - 1; i >= 0; i--) {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'b'; b.dataset.i = i; b.textContent = '0'; b.title = `${label}[${i}]`;
      bitsEl.appendChild(b);
    }
    let val = 0;
    const num = el.querySelector('.num');
    bitsEl.addEventListener('click', (e) => {
      const b = e.target.closest('.b');
      if (b) onChange(val ^ (1 << +b.dataset.i));
    });
    const commit = () => {
      let v = parseInt(num.value, 10);
      if (isNaN(v)) v = 0;
      v = w === 16 ? Math.max(-32768, Math.min(65535, v)) : Math.max(0, Math.min(max, v));
      onChange(v & max);
    };
    num.addEventListener('change', commit);
    num.addEventListener('keydown', (e) => { if (e.key === 'Enter') { commit(); num.blur(); } });
    el.querySelector('[data-a=rnd]').addEventListener('click', () => onChange(Math.floor(Math.random() * (max + 1))));
    el.querySelector('[data-a=clr]').addEventListener('click', () => onChange(0));
    const bitEls = $$('.b', bitsEl);
    return {
      el,
      set(v) {
        val = v & max;
        if (document.activeElement !== num) num.value = w === 16 ? s16(val) : val;
        bitEls.forEach((b) => {
          const on = (val >> +b.dataset.i) & 1;
          b.classList.toggle('on', !!on);
          b.textContent = on;
        });
        el.querySelector('.readout').textContent = w === 16
          ? `signed ${s16(val)} · unsigned ${val} · ${hex(val)}`
          : `binary ${bin(val, w)}`;
      },
    };
  }

  function Seg(label, n, onChange) {
    const w = Math.round(Math.log2(n));
    const el = html(`<div class="word"><div class="word-top"><span class="wn">${esc(label)}</span><span class="ww">[${w}]</span><span class="readout"></span></div><div class="seg"></div></div>`);
    const seg = el.querySelector('.seg');
    for (let i = 0; i < n; i++) {
      const b = document.createElement('button');
      b.type = 'button'; b.textContent = i; b.dataset.v = i;
      b.addEventListener('click', () => onChange(i));
      seg.appendChild(b);
    }
    return {
      el,
      set(v) {
        $$('button', seg).forEach((b) => b.classList.toggle('on', +b.dataset.v === v));
        el.querySelector('.readout').textContent = `= ${bin(v, w)}₂`;
      },
    };
  }

  /* ================================================================ *
   *  Demo engine (one per chip page)                                  *
   * ================================================================ */
  class Demo {
    constructor(id, cfg) {
      this.id = id;
      this.cfg = cfg;
      this.def = cfg.def;
      this.sim = new H.Sim(this.def);
      this.history = [];
      this.busy = false;
      this.auto = false;
      this.speed = 800;
      this.loopToken = 0;
      this.guess = null;
      this.score = { ok: 0, n: 0 };
      this.root = $(`[data-demo="${id}"]`);
      this.build();
    }

    build() {
      const c = this.cfg;
      this.root.innerHTML = `
        <div class="demo-bar">
          <div class="dt"><span class="live-dot"></span>Live demo <span class="pill">${c.file}</span></div>
          <div class="clockbar" data-r="clock"></div>
        </div>
        <div class="inputs-row" data-r="inputs"><div class="lbl-group">Inputs</div></div>
        <div class="demo-mid">
          <div><div class="sub-t">Circuit <span class="hint">${c.circHint || 'click a round input pin to toggle it'}</span></div><div class="circ-wrap" data-r="circuit"></div></div>
          <div><div class="sub-t">${c.file} — running <span class="hint">${c.def.builtin ? 'built-in: no parts inside' : 'badges = live signal values'}</span></div><div data-r="code"></div></div>
        </div>
        <div class="demo-low">
          <div class="narr">
            <div class="now"><div class="h">Right now</div><div data-r="now"></div></div>
            <div class="last" data-r="lastbox"><div class="h">Last clock edge</div><div data-r="last">No clock edge yet — press <b>Clock</b>.</div></div>
          </div>
          <div><div class="predict" data-r="predict"></div><div class="log" data-r="log"></div></div>
        </div>
        <div class="wave-box"><div class="sub-t">Timing diagram <span class="hint">one column per cycle · outputs change only at the edges (dashed lines)</span></div><div class="wave-scroll" data-r="wave"></div></div>`;
      const r = (k) => this.root.querySelector(`[data-r="${k}"]`);
      this.el = {
        clock: r('clock'), inputs: r('inputs'), circuit: r('circuit'), code: r('code'), now: r('now'),
        last: r('last'), lastbox: r('lastbox'), predict: r('predict'), log: r('log'), wave: r('wave'),
      };
      this.buildClock();
      this.controls = {};
      for (const p of c.inputs) {
        let ctl;
        const on = (v) => this.setInput(p.name, v);
        if (p.w === 1) ctl = Switch(p.name, on);
        else if (p.seg) ctl = Seg(p.name, 1 << p.w, on);
        else ctl = Word(p.name, p.w, on);
        this.controls[p.name] = ctl;
        this.el.inputs.appendChild(ctl.el);
      }
      c.buildCircuit(this);
      this.svg = this.el.circuit.querySelector('svg');
      this.el.circuit.addEventListener('click', (e) => {
        const t = e.target.closest('[data-click]');
        if (t) { this.setInput(t.dataset.click, this.val(t.dataset.click) ^ 1); return; }
        const reg = e.target.closest('[data-reg]');
        if (reg) this.setInput('address', +reg.dataset.reg);
      });
      this.code = new CodeView(this.el.code, this.def, this.sim);
      this.buildPredict();
      this.sim.eval();
      this.refresh(false);
    }

    buildClock() {
      this.el.clock.innerHTML = `
        <button class="btn clk" type="button" data-a="clock" title="One clock cycle (tick + tock)">⏱ Clock <span class="k">C</span></button>
        <button class="btn" type="button" data-a="auto" title="Keep clocking">▶ Auto <span class="k">A</span></button>
        <select class="speed" aria-label="Speed"><option value="1500">Slow</option><option value="800" selected>Normal</option><option value="320">Fast</option></select>
        <button class="btn ghost" type="button" data-a="rand" title="Random inputs">🎲</button>
        <button class="btn ghost" type="button" data-a="reset" title="Reset all state to 0">↺ Reset</button>
        <span class="tbadge">t = 0</span>`;
      const q = (a) => this.el.clock.querySelector(`[data-a="${a}"]`);
      q('clock').addEventListener('click', () => this.clock());
      q('auto').addEventListener('click', () => this.toggleAuto());
      q('rand').addEventListener('click', () => this.randomize());
      q('reset').addEventListener('click', () => this.reset());
      this.el.clock.querySelector('.speed').addEventListener('change', (e) => { this.speed = +e.target.value; });
      this.autoBtn = q('auto');
      this.timeBadge = this.el.clock.querySelector('.tbadge');
    }

    buildPredict() {
      const p = this.cfg.predict;
      const host = this.el.predict;
      host.innerHTML = `<div class="ph"><span>🔮 Predict <code>${p.name}</code> after the next clock edge</span><span class="score">score 0 / 0</span></div><div class="pb"></div><div class="pr"></div>`;
      const pb = host.querySelector('.pb');
      this.prMsg = host.querySelector('.pr');
      this.prScore = host.querySelector('.score');
      if (p.w === 1) {
        [0, 1].forEach((v) => {
          const b = html(`<button class="btn pick" type="button">${v}</button>`);
          b.addEventListener('click', () => {
            this.guess = v;
            $$('.pick', pb).forEach((x) => x.classList.toggle('sel', x === b));
            this.prMsg.className = 'pr';
            this.prMsg.textContent = `Locked in: ${p.name} = ${v}. Now press Clock.`;
          });
          pb.appendChild(b);
        });
      } else {
        const inp = html('<input class="num" type="number" placeholder="value" aria-label="Predicted value">');
        const b = html('<button class="btn pick" type="button">Lock in</button>');
        const lock = () => {
          const v = parseInt(inp.value, 10);
          if (isNaN(v)) { this.prMsg.className = 'pr'; this.prMsg.textContent = 'Type a number first.'; return; }
          this.guess = v & 0xffff;
          b.classList.add('sel');
          this.prMsg.className = 'pr';
          this.prMsg.textContent = `Locked in: ${p.name} = ${s16(this.guess)}. Now press Clock.`;
        };
        b.addEventListener('click', lock);
        inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') lock(); });
        pb.append(inp, b);
        this.prInput = inp;
      }
    }

    checkPrediction(after) {
      if (this.guess === null) return;
      const p = this.cfg.predict;
      const actual = after[p.name];
      const ok = (this.guess & mask(p.w)) === actual;
      this.score.n++;
      if (ok) this.score.ok++;
      this.prScore.textContent = `score ${this.score.ok} / ${this.score.n}`;
      this.prMsg.className = 'pr ' + (ok ? 'good' : 'bad');
      this.prMsg.textContent = ok
        ? `✓ Correct — ${p.name} = ${fmt(actual, p.w)}.`
        : `✗ You said ${fmt(this.guess, p.w)}, but ${p.name} = ${fmt(actual, p.w)}. Read “Last clock edge” to see why.`;
      this.guess = null;
      $$('.pick', this.el.predict).forEach((x) => x.classList.remove('sel'));
      if (this.prInput) this.prInput.value = '';
    }

    val(name) { return this.sim.get(name); }

    snapshot() {
      const o = {};
      for (const k of Object.keys(this.sim.widths)) o[k] = this.sim.get(k);
      return o;
    }

    setInput(name, v) {
      this.sim.set(name, v);
      this.sim.eval();
      this.refresh(true);
    }

    refresh(flash) {
      for (const p of this.cfg.inputs) this.controls[p.name].set(this.sim.get(p.name));
      paintCircuit(this);
      if (this.cfg.paint) this.cfg.paint(this);
      this.code.update(flash);
      this.el.now.innerHTML = this.cfg.now(this);
      const entries = this.history.slice(-13).concat([this.snapshot()]);
      renderWave(this.el.wave, this.cfg.trace, entries, this.sim.time - (entries.length - 1));
      this.timeBadge.textContent = `t = ${this.sim.time}${this.sim.half ? '+' : ''}`;
      this.timeBadge.classList.toggle('tick', this.sim.half);
    }

    showTag(key, text) {
      const t = this.svg && this.svg.querySelector(`[data-tag="${key}"]`);
      if (!t) return;
      if (text !== undefined) t.textContent = text;
      t.classList.add('show');
    }
    hideTags() { if (this.svg) $$('.tag', this.svg).forEach((t) => t.classList.remove('show')); }
    flashClock(on) { if (this.svg) $$('.clkw', this.svg).forEach((w) => w.classList.toggle('flash', on)); }

    async clock() {
      if (this.busy) return;
      this.busy = true;
      const before = this.snapshot();
      const t = this.sim.time;
      const anim = this.auto ? Math.min(520, this.speed * 0.5) : 620;
      this.sim.tick();
      this.flashClock(true);
      if (this.cfg.onTick) this.cfg.onTick(this, before, anim * 0.6);
      this.refresh(false);
      await sleep(anim * 0.6);
      this.sim.tock();
      const after = this.snapshot();
      this.history.push(before);
      if (this.history.length > 300) this.history.shift();
      this.flashClock(false);
      this.refresh(true);
      if (this.cfg.onTock) this.cfg.onTock(this, before, after);
      const msg = this.cfg.edge(this, before, after, t);
      this.el.last.innerHTML = msg.long;
      restartAnim(this.el.lastbox, 'fresh');
      this.addLog(t, msg.short);
      this.checkPrediction(after);
      await sleep(anim * 0.4);
      this.hideTags();
      this.busy = false;
    }

    addLog(t, text) {
      const row = html(`<div><span class="t">t ${t}→${t + 1}</span>${text}</div>`);
      this.el.log.prepend(row);
      while (this.el.log.children.length > 12) this.el.log.lastElementChild.remove();
    }

    toggleAuto(force) {
      this.auto = force === undefined ? !this.auto : force;
      this.autoBtn.classList.toggle('on', this.auto);
      this.autoBtn.innerHTML = this.auto ? '⏸ Pause <span class="k">A</span>' : '▶ Auto <span class="k">A</span>';
      if (this.auto) this.loop();
    }
    stopAuto() { if (this.auto) this.toggleAuto(false); }
    async loop() {
      const token = ++this.loopToken;
      while (this.auto && token === this.loopToken) {
        await this.clock();
        await sleep(Math.max(60, this.speed * 0.5));
      }
    }

    randomize() {
      for (const p of this.cfg.inputs) {
        const v = p.w === 1 ? (Math.random() < (p.p === undefined ? 0.5 : p.p) ? 1 : 0) : Math.floor(Math.random() * (1 << p.w));
        this.sim.set(p.name, v);
      }
      this.sim.eval();
      this.refresh(true);
    }

    reset() {
      this.stopAuto();
      this.sim.reset();
      this.history = [];
      this.el.log.innerHTML = '';
      this.el.last.innerHTML = 'State reset to 0. Press <b>Clock</b>.';
      this.hideTags();
      this.refresh(false);
    }
  }

  // Generic painter: wires (data-w), pins (data-p), value text (data-t), binary text (data-bin)
  function paintCircuit(d) {
    const svg = d.el.circuit;
    $$('[data-w]', svg).forEach((e) => {
      const n = e.dataset.w;
      e.classList.toggle('on', d.sim.width(n) === 1 && !!d.val(n));
    });
    $$('[data-p]', svg).forEach((e) => { e.classList.toggle('on', !!d.val(e.dataset.p)); });
    $$('[data-t]', svg).forEach((e) => { const n = e.dataset.t; e.textContent = fmt(d.val(n), d.sim.width(n)); });
    $$('[data-bin]', svg).forEach((e) => { const n = e.dataset.bin; e.textContent = bin(d.val(n), d.sim.width(n)); });
  }

  const pin1 = (name, cx, cy, label, side) => `
    <g class="clickable" data-click="${name}" role="button" aria-label="toggle ${name}">
      <circle class="pin" data-p="${name}" cx="${cx}" cy="${cy}" r="16"/>
      <text class="pintxt" x="${cx}" y="${cy}" data-t="${name}">0</text></g>
    ${side === 'right'
    ? `<text class="pinlbl" x="${cx + 22}" y="${cy + 5}" style="text-anchor:start">${label || name}</text>`
    : `<text class="pinlbl" x="${cx}" y="${cy - 26}">${label || name}</text>`}`;
  const pinOut1 = (name, sig, cx, cy, label) => `
    <circle class="pin" data-p="${sig}" cx="${cx}" cy="${cy}" r="16"/>
    <text class="pintxt" x="${cx}" y="${cy}" data-t="${sig}">0</text>
    <text class="pinlbl" x="${cx}" y="${cy - 26}">${label || name}</text>`;
  const pinBus = (sig, x, y, w, label, ly) => `
    <rect class="pin busp" x="${x}" y="${y - 14}" width="${w}" height="28" rx="8"/>
    <text class="pintxt" x="${x + w / 2}" y="${y}" data-t="${sig}">0</text>
    <text class="pinlbl" x="${x + w / 2}" y="${ly === undefined ? y - 22 : ly}">${label}</text>`;

  /* ================================================================ *
   *  01 · DFF                                                         *
   * ================================================================ */
  function makeDFF() {
    demos.dff = new Demo('dff', {
      def: H.compile(SRC.DFF),
      file: 'DFF.hdl',
      inputs: [{ name: 'in', w: 1 }],
      trace: [{ name: 'in', w: 1 }, { name: 'out', w: 1 }],
      predict: { name: 'out', w: 1 },
      buildCircuit(d) {
        d.el.circuit.innerHTML = `
        <svg class="circ" viewBox="0 0 560 230" role="img" aria-label="DFF circuit">
          <path class="w" data-w="in" d="M56 100 H200"/>
          ${pin1('in', 40, 100)}
          <rect class="chipbox" data-box="dff" x="200" y="50" width="160" height="100" rx="12"/>
          <text class="cname" x="280" y="75">DFF</text>
          <text class="clbl mid" x="280" y="93">stored</text>
          <text class="cval" x="280" y="128" data-t="out">0</text>
          <path class="clkt" d="M268 150 L280 136 L292 150"/>
          <path class="w clkw" d="M280 212 V150"/>
          <text class="clbl" x="292" y="210">clk</text>
          <text class="tag" data-tag="cap" x="280" y="40">sampled in = 0</text>
          <path class="w" data-w="out" d="M360 100 H504"/>
          ${pinOut1('out', 'out', 520, 100)}
        </svg>`;
      },
      now(d) {
        const i = d.val('in'), o = d.val('out');
        if (d.sim.half) return `Tick! The DFF has just sampled <code>in</code> = ${b1(i)}. On the tock it appears on <code>out</code>.`;
        return `The DFF is holding ${b1(o)} — that is what <code>out</code> shows during this whole cycle. <code>in</code> is ${b1(i)} right now. At the next rising edge the DFF copies it, so <code>out</code> will become ${b1(i)}${i === o ? ' (no visible change).' : '.'}`;
      },
      onTick(d, b, dur) {
        d.showTag('cap', `sampled in = ${b.in}`);
        d.svg.querySelector('[data-box]').classList.add('capture');
        pulseAlong(d.svg, 'M56 100 H200', dur);
      },
      onTock(d, b, a) {
        const box = d.svg.querySelector('[data-box]');
        box.classList.remove('capture');
        if (b.out !== a.out) restartAnim(box, 'flipped');
      },
      edge(d, b, a, t) {
        return {
          long: `At the edge after <code>t = ${t}</code> the DFF sampled <code>in = ${b.in}</code>. So <code>out(${t + 1}) = in(${t}) = ${a.out}</code>${b.out !== a.out ? ` — it changed ${b.out} → ${a.out}.` : ' — no change.'}`,
          short: `in was ${b.in} → out = ${a.out}`,
        };
      },
    });
  }

  /* ================================================================ *
   *  02 · Bit                                                         *
   * ================================================================ */
  function makeBit() {
    demos.bit = new Demo('bit', {
      def: H.compile(SRC.Bit),
      file: 'Bit.hdl',
      inputs: [{ name: 'in', w: 1 }, { name: 'load', w: 1, p: 0.4 }],
      trace: [{ name: 'in', w: 1 }, { name: 'load', w: 1 }, { name: 'out', w: 1 }],
      predict: { name: 'out', w: 1 },
      buildCircuit(d) {
        d.el.circuit.innerHTML = `
        <svg class="circ" viewBox="0 0 640 270" role="img" aria-label="Bit circuit: Mux and DFF with feedback">
          <path class="w" data-w="dffOut" d="M510 115 V30 H170 V90 H200"/>
          <path class="flow" data-flow="a" d="M510 115 V30 H170 V90 H200"/>
          <text class="wval mid" x="340" y="22">dffOut (feedback) = <tspan data-t="dffOut">0</tspan></text>
          <path class="w" data-w="in" d="M56 140 H200"/>
          <path class="flow" data-flow="b" d="M56 140 H200"/>
          ${pin1('in', 40, 140)}
          <path class="w" data-w="load" d="M56 235 H230 V160"/>
          ${pin1('load', 40, 235)}
          <text class="clbl" x="238" y="205">sel</text>
          <polygon class="gate" points="200,60 260,80 260,150 200,170"/>
          <text class="clbl mid" x="230" y="54">Mux</text>
          <text class="clbl" x="206" y="86">a</text>
          <text class="clbl" x="206" y="150">b</text>
          <path class="mpath" data-mux="1" d="M204 90 L256 115"/>
          <path class="w" data-w="muxOut" d="M260 115 H360"/>
          <path class="flow" d="M260 115 H360"/>
          <text class="wval mid" x="310" y="106">muxOut=<tspan data-t="muxOut">0</tspan></text>
          <rect class="chipbox" data-box="dff" x="360" y="70" width="100" height="90" rx="10"/>
          <text class="cname" x="410" y="92">DFF</text>
          <text class="cval" x="410" y="133" data-t="dffOut">0</text>
          <path class="clkt" d="M398 160 L410 146 L422 160"/>
          <path class="w clkw" d="M410 258 V160"/>
          <text class="clbl" x="420" y="256">clk</text>
          <text class="tag" data-tag="cap" x="410" y="62">sampled 0</text>
          <path class="w" data-w="out" d="M460 115 H584"/>
          <circle class="dot" data-dot="1" cx="510" cy="115" r="5"/>
          ${pinOut1('out', 'out', 600, 115)}
        </svg>`;
      },
      paint(d) {
        const load = d.val('load'), inn = d.val('in');
        d.svg.querySelector('[data-mux]').setAttribute('d', load ? 'M204 140 L256 115' : 'M204 90 L256 115');
        d.svg.querySelector('[data-flow="a"]').style.display = load ? 'none' : '';
        d.svg.querySelector('[data-flow="b"]').style.display = load ? '' : 'none';
        d.svg.querySelector('[data-dot]').classList.toggle('on', !!d.val('out'));
        $$('#bitTable tbody tr').forEach((tr) => tr.classList.toggle('act', tr.dataset.k === `${load}${inn}`));
      },
      now(d) {
        const l = d.val('load'), i = d.val('in'), o = d.val('out');
        if (l) {
          return `<code>load = 1</code> → the Mux selects <b>b</b> = <code>in</code> = ${b1(i)}, so <code>muxOut</code> = ${b1(i)} waits at the DFF's input. After the next edge <code>out</code> = ${b1(i)}${i === o ? ' (same as now).' : ' — it will change.'}`;
        }
        return `<code>load = 0</code> → the Mux selects <b>a</b> = the DFF's own output (${b1(o)}). The value just goes around the loop, so after the next edge <code>out</code> stays ${b1(o)}. Toggling <code>in</code> now changes nothing — try it.`;
      },
      onTick(d, b, dur) {
        d.showTag('cap', `sampled ${b.muxOut}`);
        d.svg.querySelector('[data-box]').classList.add('capture');
        pulseAlong(d.svg, 'M260 115 H360', dur);
      },
      onTock(d, b, a) {
        const box = d.svg.querySelector('[data-box]');
        box.classList.remove('capture');
        if (b.out !== a.out) restartAnim(box, 'flipped');
      },
      edge(d, b, a, t) {
        const long = b.load
          ? `At the edge after <code>t = ${t}</code>, <code>load</code> was 1, so the Bit <b>stored</b> <code>in = ${b.in}</code>. Now <code>out</code> = ${b1(a.out)}${b.out !== a.out ? ` (changed from ${b.out}).` : ' (it already was).'}`
          : `At the edge after <code>t = ${t}</code>, <code>load</code> was 0, so the DFF just took back its own value. <code>out</code> stays ${b1(a.out)}${b.in !== a.out ? ` even though <code>in</code> was ${b.in}.` : '.'}`;
        return { long, short: b.load ? `load=1 → stored ${b.in}` : `load=0 → kept ${a.out}` };
      },
    });
  }

  /* ================================================================ *
   *  03 · Register                                                    *
   * ================================================================ */
  function makeRegister() {
    demos.register = new Demo('register', {
      def: H.compile(SRC.Register),
      file: 'Register.hdl',
      circHint: 'click an in-bit to toggle it',
      inputs: [{ name: 'in', w: 16 }, { name: 'load', w: 1, p: 0.5 }],
      trace: [{ name: 'load', w: 1 }, { name: 'in', w: 16 }, { name: 'out', w: 16 }],
      predict: { name: 'out', w: 16 },
      buildCircuit(d) {
        const idx = Array.from({ length: 16 }, (_, k) => 15 - k);
        let h = '<div class="regviz">';
        h += '<div class="rl">in</div>' + idx.map((i) => `<button class="rin" type="button" data-i="${i}" title="in[${i}] — click to toggle">0</button>`).join('');
        h += '<div></div>' + idx.map((i) => `<div class="vline" data-v="${i}"></div>`).join('');
        h += '<div class="rl">load</div><div class="loadbus"></div>';
        h += '<div class="rl">Bit</div>' + idx.map((i) => `<div class="rbit" data-b="${i}"><span class="bv">0</span></div>`).join('');
        h += '<div></div>' + idx.map((i) => `<div class="vline" data-o="${i}"></div>`).join('');
        h += '<div class="rl">out</div>' + idx.map((i) => `<div class="rout" data-o="${i}">0</div>`).join('');
        h += '<div></div>' + idx.map((i) => `<div class="ri">${i}</div>`).join('');
        h += '</div><div class="regnums"><div><div class="k">in (signed)</div><div class="v" data-n="in">0</div></div><div><div class="k">out (signed)</div><div class="v" data-n="out">0</div></div><div><div class="k">out (hex · unsigned)</div><div class="v" data-n="hex">0</div></div></div>';
        d.el.circuit.innerHTML = h;
        d.el.circuit.addEventListener('click', (e) => {
          const b = e.target.closest('.rin');
          if (b) d.setInput('in', d.val('in') ^ (1 << +b.dataset.i));
        });
      },
      paint(d) {
        const inn = d.val('in'), out = d.val('out'), load = d.val('load');
        const c = d.el.circuit;
        $$('.rin', c).forEach((e) => { const v = (inn >> e.dataset.i) & 1; e.classList.toggle('on', !!v); e.textContent = v; });
        $$('.vline[data-v]', c).forEach((e) => e.classList.toggle('on', !!((inn >> e.dataset.v) & 1)));
        $$('.vline[data-o]', c).forEach((e) => e.classList.toggle('on', !!((out >> e.dataset.o) & 1)));
        $$('.rbit', c).forEach((e) => {
          const i = +e.dataset.b, v = (out >> i) & 1;
          e.classList.toggle('on', !!v);
          e.classList.toggle('armed', !!load && ((inn >> i) & 1) !== v);
          e.querySelector('.bv').textContent = v;
        });
        $$('.rout', c).forEach((e) => { const v = (out >> e.dataset.o) & 1; e.classList.toggle('on', !!v); e.textContent = v; });
        $('.loadbus', c).classList.toggle('on', !!load);
        $('[data-n="in"]', c).textContent = s16(inn);
        $('[data-n="out"]', c).textContent = s16(out);
        $('[data-n="hex"]', c).textContent = `${hex(out)} · ${out}`;
      },
      now(d) {
        const inn = d.val('in'), out = d.val('out');
        if (d.val('load')) {
          const k = popcount(inn ^ out);
          return `<code>load = 1</code> reaches all 16 Bits at once. At the next edge each Bit copies its <code>in[i]</code>, so <code>out</code> becomes ${n16(inn)}. ${k ? `${k} bit${k > 1 ? 's' : ''} will flip (outlined in amber).` : 'No bit will change — the value is already stored.'}`;
        }
        return `<code>load = 0</code> → every Bit keeps its value. <code>out</code> stays ${n16(out)} (<code>${bin(out, 16)}</code>) no matter what <code>in</code> is.`;
      },
      onTick(d) { if (d.val('load')) $$('.rbit.armed', d.el.circuit).forEach((e) => e.classList.add('flip')); },
      onTock(d, b, a) {
        $$('.rbit', d.el.circuit).forEach((e) => {
          e.classList.remove('flip');
          if (((b.out ^ a.out) >> e.dataset.b) & 1) restartAnim(e, 'flip');
        });
      },
      edge(d, b, a, t) {
        const k = popcount(b.out ^ a.out);
        const long = b.load
          ? `After <code>t = ${t}</code>: <code>load</code> was 1, so all 16 Bits stored their inputs. <code>out</code> = ${n16(a.out)} — ${k} bit${k === 1 ? '' : 's'} changed.`
          : `After <code>t = ${t}</code>: <code>load</code> was 0, so the register kept ${n16(a.out)} and ignored <code>in = ${s16(b.in)}</code>.`;
        return { long, short: b.load ? `stored ${s16(b.in)}` : `kept ${s16(a.out)}` };
      },
    });
  }

  /* ================================================================ *
   *  04 · RAM8                                                        *
   * ================================================================ */
  function makeRAM8() {
    const RY = (i) => 40 + i * 46;
    demos.ram8 = new Demo('ram8', {
      def: H.compile(SRC.RAM8),
      file: 'RAM8.hdl',
      circHint: 'click a register to select its address',
      inputs: [{ name: 'in', w: 16 }, { name: 'load', w: 1, p: 0.5 }, { name: 'address', w: 3, seg: true }],
      trace: [{ name: 'address', w: 3, label: 'address' }, { name: 'load', w: 1 }, { name: 'in', w: 16 }, { name: 'out', w: 16 }],
      predict: { name: 'out', w: 16 },
      buildCircuit(d) {
        let s = '<svg class="circ" viewBox="0 0 780 446" style="min-width:600px" role="img" aria-label="RAM8 circuit">';
        s += `<path class="w bus" d="M100 22 H260 V${RY(7) + 26}"/>`;
        for (let i = 0; i < 8; i++) s += `<path class="w bus" d="M260 ${RY(i) + 26} H300"/>`;
        s += pinBus('in', 8, 22, 92, 'in[16]', 52);
        s += '<path class="w" data-w="load" d="M56 220 H140"/>';
        s += pin1('load', 40, 220);
        s += '<path class="w bus" d="M100 428 H585 V395"/><path class="w bus" d="M170 428 V400"/>';
        s += '<circle cx="170" cy="428" r="5" style="fill:var(--bus)"/>';
        s += pinBus('address', 8, 428, 92, 'address[3]', 406);
        s += '<rect class="chipbox" x="140" y="40" width="60" height="360" rx="8"/>';
        s += '<text class="cname" transform="translate(176 220) rotate(-90)" style="font-size:13px">DMux8Way</text>';
        for (let i = 0; i < 8; i++) {
          s += `<path class="w" data-w="l${i}" d="M200 ${RY(i) + 12} H300"/>`;
          s += `<text class="clbl" x="206" y="${RY(i) + 8}">l${i}</text>`;
        }
        for (let i = 0; i < 8; i++) {
          s += `<g data-reg="${i}" style="cursor:pointer"><rect class="chipbox" data-box="r${i}" x="300" y="${RY(i)}" width="190" height="36" rx="7"/>
            <text class="clbl" x="312" y="${RY(i) + 15}">Register ${i}</text>
            <text class="clbl" x="312" y="${RY(i) + 30}" style="font-size:9.5px;fill:var(--dim)" data-bin="r${i}">0</text>
            <text class="cval" x="480" y="${RY(i) + 25}" style="font-size:15px;text-anchor:end" data-t="r${i}">0</text></g>`;
          s += `<path class="w bus" data-rw="${i}" d="M490 ${RY(i) + 18} H560"/>`;
        }
        s += '<polygon class="gate" points="560,30 610,60 610,380 560,410"/>';
        s += '<text class="cname" transform="translate(590 220) rotate(-90)" style="font-size:13px">Mux8Way16</text>';
        s += '<path class="mpath" data-mp="1" d="M564 58 L606 220"/>';
        s += '<path class="w bus" d="M610 220 H690"/><path class="flow" d="M610 220 H690"/>';
        s += pinBus('out', 690, 220, 84, 'out[16]');
        s += '<text class="tag" data-tag="w" x="395" y="30">write!</text>';
        d.el.circuit.innerHTML = s + '</svg>';
      },
      paint(d) {
        const a = d.val('address'), load = d.val('load');
        for (let i = 0; i < 8; i++) {
          const box = d.svg.querySelector(`[data-box="r${i}"]`);
          box.classList.toggle('sel', i === a);
          box.classList.toggle('write', !!load && i === a);
          d.svg.querySelector(`[data-rw="${i}"]`).classList.toggle('dim', i !== a);
        }
        d.svg.querySelector('[data-mp]').setAttribute('d', `M564 ${RY(a) + 18} L606 220`);
      },
      now(d) {
        const a = d.val('address'), inn = d.val('in'), ra = d.val('r' + a);
        let s = `<b>Read:</b> <code>address = ${a}</code> → Mux8Way16 routes Register ${a} (${n16(ra)}) to <code>out</code>. This is instant: change the address and <code>out</code> changes with no clock.<br>`;
        s += d.val('load')
          ? `<b>Write:</b> <code>load = 1</code> → DMux8Way sends it to <code>l${a}</code> only. At the next edge Register ${a} stores <code>in</code> = ${n16(inn)}; the other 7 get <code>load = 0</code> and keep their values.`
          : `<b>Write:</b> <code>load = 0</code> → all eight <code>l</code> lines are 0, so nothing will be written. <code>in</code> (${n16(inn)}) reaches every register, but none stores it.`;
        return s;
      },
      onTick(d, b, dur) {
        if (!b.load) return;
        const a = b.address;
        const t = d.svg.querySelector('[data-tag="w"]');
        t.setAttribute('y', RY(a) - 4);
        d.showTag('w', `writing ${s16(b.in)} → Register ${a}`);
        d.svg.querySelector(`[data-box="r${a}"]`).classList.add('capture');
        pulseAlong(d.svg, `M200 ${RY(a) + 12} H300`, dur);
      },
      onTock(d, b) {
        $$('.chipbox.capture', d.svg).forEach((x) => x.classList.remove('capture'));
        if (b.load) restartAnim(d.svg.querySelector(`[data-box="r${b.address}"]`), 'flipped');
      },
      edge(d, b, a, t) {
        const long = b.load
          ? `After <code>t = ${t}</code>: wrote ${n16(b.in)} into <b>Register ${b.address}</b> (because <code>load = 1</code> and <code>address = ${b.address}</code>). <code>out</code> now reads ${n16(a.out)}.`
          : `After <code>t = ${t}</code>: <code>load</code> was 0 — no register changed. <code>out</code> still reads Register ${a.address} = ${n16(a.out)}.`;
        return { long, short: b.load ? `RAM[${b.address}] ← ${s16(b.in)}` : 'no write' };
      },
    });
  }

  /* ================================================================ *
   *  05 · PC                                                          *
   * ================================================================ */
  function makePC() {
    const ROUTES = {
      reset: ['M418 160 H440', 'M490 140 H560'],
      load: ['M80 210 H310 V140 H330', 'M380 120 H440', 'M490 140 H560'],
      inc: ['M720 140 V30 H50 V125 H90', 'M160 125 H220', 'M270 100 H330', 'M380 120 H440', 'M490 140 H560'],
      hold: ['M720 140 V30 H50 V75 H220', 'M270 100 H330', 'M380 120 H440', 'M490 140 H560'],
    };
    const mode = (v) => (v.reset ? 'reset' : v.load ? 'load' : v.inc ? 'inc' : 'hold');
    const ctlBits = (d) => ({ reset: d.val('reset'), load: d.val('load'), inc: d.val('inc') });
    demos.pc = new Demo('pc', {
      def: H.compile(SRC.PC),
      file: 'PC.hdl',
      inputs: [{ name: 'in', w: 16 }, { name: 'load', w: 1, p: 0.25 }, { name: 'inc', w: 1, p: 0.8 }, { name: 'reset', w: 1, p: 0.1 }],
      trace: [{ name: 'reset', w: 1 }, { name: 'load', w: 1 }, { name: 'inc', w: 1 }, { name: 'in', w: 16 }, { name: 'out', w: 16 }],
      predict: { name: 'out', w: 16 },
      buildCircuit(d) {
        d.el.circuit.innerHTML = `
        <svg class="circ" viewBox="0 0 840 305" style="min-width:620px" role="img" aria-label="PC circuit">
          <path class="w bus" d="M720 140 V30 H50 V125 H90"/>
          <path class="w bus" d="M50 75 H220"/>
          <circle cx="50" cy="75" r="5" style="fill:var(--bus)"/><circle cx="720" cy="140" r="5" style="fill:var(--bus)"/>
          <text class="wval busv mid" x="385" y="22">feedback = <tspan data-t="feedback">0</tspan></text>
          <rect class="chipbox" x="90" y="100" width="70" height="50" rx="8"/>
          <text class="cname" x="125" y="130" style="font-size:13px">Inc16</text>
          <path class="w bus" d="M160 125 H220"/>
          <text class="wval busv mid" x="190" y="117" style="font-size:10.5px" data-t="plusOne">1</text>
          <polygon class="gate" points="220,55 270,70 270,130 220,145"/>
          <text class="clbl mid" x="245" y="49">Mux16</text>
          <path class="mpath" data-m="1" d="M224 75 L266 100"/>
          <path class="w bus" d="M270 100 H330"/>
          <text class="wval busv mid" x="300" y="92" style="font-size:10.5px" data-t="afterInc">0</text>
          <polygon class="gate" points="330,75 380,90 380,150 330,165"/>
          <text class="clbl mid" x="355" y="69">Mux16</text>
          <path class="mpath" data-m="2" d="M334 100 L376 120"/>
          <path class="w bus" d="M380 120 H440"/>
          <text class="wval busv mid" x="410" y="112" style="font-size:10.5px" data-t="afterLoad">0</text>
          <polygon class="gate" points="440,95 490,110 490,170 440,185"/>
          <text class="clbl mid" x="465" y="89">Mux16</text>
          <path class="mpath" data-m="3" d="M444 120 L486 140"/>
          <path class="w bus" d="M418 160 H440"/>
          <text class="wval mid" x="410" y="164">0</text>
          <path class="w bus" d="M490 140 H560"/>
          <text class="wval busv mid" x="525" y="132" style="font-size:10.5px" data-t="next">0</text>
          <g data-flows="1"></g>
          <rect class="chipbox" data-box="reg" x="560" y="105" width="110" height="70" rx="10"/>
          <text class="cname" x="615" y="124" style="font-size:13px">Register</text>
          <text class="cval" x="615" y="153" style="font-size:20px" data-t="out">0</text>
          <path class="clkt" d="M603 175 L615 162 L627 175"/>
          <text class="clbl mid" x="615" y="96">load = true</text>
          <path class="w clkw" d="M615 212 V175"/>
          <text class="clbl" x="624" y="210">clk</text>
          <text class="tag" data-tag="cap" x="700" y="196">sampled</text>
          <path class="w bus" d="M670 140 H760"/>
          ${pinBus('out', 760, 140, 74, 'out')}
          ${pinBus('in', 6, 210, 74, 'in')}
          <path class="w bus" d="M80 210 H310 V140 H330"/>
          <path class="w" data-w="inc" d="M245 262 V138"/>
          <path class="w" data-w="load" d="M355 262 V158"/>
          <path class="w" data-w="reset" d="M465 262 V178"/>
          ${pin1('inc', 245, 280, 'inc', 'right')}
          ${pin1('load', 355, 280, 'load', 'right')}
          ${pin1('reset', 465, 280, 'reset', 'right')}
          <text class="clbl" x="252" y="152">sel</text><text class="clbl" x="362" y="172">sel</text><text class="clbl" x="472" y="192">sel</text>
        </svg>`;
      },
      paint(d) {
        const c = ctlBits(d);
        const m = mode(c);
        d.svg.querySelector('[data-m="1"]').setAttribute('d', c.inc ? 'M224 125 L266 100' : 'M224 75 L266 100');
        d.svg.querySelector('[data-m="2"]').setAttribute('d', c.load ? 'M334 140 L376 120' : 'M334 100 L376 120');
        d.svg.querySelector('[data-m="3"]').setAttribute('d', c.reset ? 'M444 160 L486 140' : 'M444 120 L486 140');
        d.svg.querySelector('[data-flows]').innerHTML = ROUTES[m].map((p) => `<path class="flow" d="${p}"/>`).join('');
        $$('#pcTable tbody tr').forEach((tr) => tr.classList.toggle('act', tr.dataset.k === m));
      },
      now(d) {
        const c = ctlBits(d), m = mode(c), out = d.val('out'), inn = d.val('in');
        const ignored = [];
        if (m === 'reset') { if (c.load) ignored.push('load'); if (c.inc) ignored.push('inc'); }
        if (m === 'load' && c.inc) ignored.push('inc');
        const ig = ignored.length ? ` (<code>${ignored.join('</code> and <code>')}</code> ${ignored.length > 1 ? 'are' : 'is'} ignored: lower priority.)` : '';
        if (m === 'reset') return `<code>reset = 1</code> has the highest priority → the last Mux16 picks the constant 0. After the edge <code>out</code> = ${n16(0)}.${ig}`;
        if (m === 'load') return `<code>load = 1</code> → the middle Mux16 picks <code>in</code> = ${n16(inn)} (a <b>jump</b>). After the edge <code>out</code> = ${n16(inn)}.${ig}`;
        if (m === 'inc') return `<code>inc = 1</code> → the first Mux16 picks <code>out + 1</code> from Inc16. After the edge <code>out</code> = ${n16((out + 1) & 0xffff)}.${out === 0x7fff ? ' Note: 32767 + 1 wraps around to −32768!' : ''}`;
        return 'All controls are 0 → every Mux16 passes the <code>feedback</code> through unchanged. <code>out</code> stays ' + n16(out) + '.';
      },
      onTick(d, b, dur) {
        d.showTag('cap', `sampled ${s16(b.next)}`);
        d.svg.querySelector('[data-box]').classList.add('capture');
        pulseAlong(d.svg, 'M490 140 H560', dur);
      },
      onTock(d, b, a) {
        const box = d.svg.querySelector('[data-box]');
        box.classList.remove('capture');
        if (b.out !== a.out) restartAnim(box, 'flipped');
      },
      edge(d, b, a, t) {
        const m = mode(b);
        const what = { reset: 'reset = 1 → out = 0', load: `load = 1 → jumped to ${s16(b.in)}`, inc: `inc = 1 → counted ${s16(b.out)} + 1`, hold: 'no control was set → held its value' }[m];
        return { long: `After <code>t = ${t}</code>: ${what}. <code>out</code> = ${n16(a.out)}.`, short: `${m}: ${s16(b.out)} → ${s16(a.out)}` };
      },
    });
  }

  /* ================================================================ *
   *  Master–slave latch explainer (DFF page)                          *
   * ================================================================ */
  function makeMasterSlave() {
    const host = $('[data-ms]');
    if (!host) return;
    const st = { D: 0, clk: 0, M: 0, S: 0 };
    host.innerHTML = `
      <div class="ms-ctrl"></div>
      <div class="circ-wrap"><svg class="circ" viewBox="0 0 600 205" style="min-width:460px" role="img" aria-label="Master-slave flip-flop">
        <path class="w" data-w="D" d="M56 80 H140"/>
        ${pin1('D', 40, 80)}
        <rect class="latch" data-l="m" x="140" y="40" width="120" height="80" rx="10"/>
        <text class="cname" x="200" y="62" style="font-size:13px">Master</text>
        <text class="cval" x="200" y="94" style="font-size:22px" data-t="M">0</text>
        <text class="clbl mid" x="200" y="112" data-st="m">open</text>
        <path class="w" data-w="M" d="M260 80 H340"/>
        <rect class="latch" data-l="s" x="340" y="40" width="120" height="80" rx="10"/>
        <text class="cname" x="400" y="62" style="font-size:13px">Slave</text>
        <text class="cval" x="400" y="94" style="font-size:22px" data-t="S">0</text>
        <text class="clbl mid" x="400" y="112" data-st="s">closed</text>
        <path class="w" data-w="S" d="M460 80 H544"/>
        <circle class="pin" data-p="S" cx="560" cy="80" r="16"/><text class="pintxt" x="560" y="80" data-t="S">0</text>
        <text class="pinlbl" x="560" y="54">Q</text>
        <path class="w" data-w="clk" d="M56 175 H400 V120"/>
        <path class="w" data-w="clk" d="M200 175 V129"/>
        <circle class="bub" cx="200" cy="124" r="5"/>
        ${pin1('clk', 40, 175)}
        <text class="clbl" x="208" y="160">enable = NOT clk</text>
        <text class="clbl" x="408" y="160">enable = clk</text>
      </svg></div>
      <div class="ms-note" data-note></div>`;
    const ctl = host.querySelector('.ms-ctrl');
    const swD = Switch('D', (v) => { st.D = v; update(); });
    const swC = Switch('clk', (v) => { st.clk = v; update(); });
    const pulseBtn = html('<button class="btn clk" type="button">⏱ Pulse clk 0→1→0</button>');
    pulseBtn.addEventListener('click', async () => {
      st.clk = 0; update(); await sleep(250);
      st.clk = 1; update(); await sleep(700);
      st.clk = 0; update();
    });
    ctl.append(swD.el, swC.el, pulseBtn);
    host.querySelector('svg').addEventListener('click', (e) => {
      const t = e.target.closest('[data-click]');
      if (!t) return;
      st[t.dataset.click] ^= 1;
      update();
    });
    function update() {
      if (!st.clk) st.M = st.D;
      if (st.clk) st.S = st.M;
      swD.set(st.D); swC.set(st.clk);
      const svg = host.querySelector('svg');
      $$('[data-w]', svg).forEach((e) => e.classList.toggle('on', !!st[e.dataset.w]));
      $$('[data-p]', svg).forEach((e) => e.classList.toggle('on', !!st[e.dataset.p]));
      $$('[data-t]', svg).forEach((e) => { e.textContent = st[e.dataset.t]; });
      const mOpen = !st.clk, sOpen = !!st.clk;
      svg.querySelector('[data-l="m"]').setAttribute('class', 'latch ' + (mOpen ? 'open' : 'closed'));
      svg.querySelector('[data-l="s"]').setAttribute('class', 'latch ' + (sOpen ? 'open' : 'closed'));
      svg.querySelector('[data-st="m"]').textContent = mOpen ? 'OPEN · follows D' : 'CLOSED · holds';
      svg.querySelector('[data-st="s"]').textContent = sOpen ? 'OPEN · follows M' : 'CLOSED · holds';
      host.querySelector('[data-note]').innerHTML = st.clk
        ? `<b>clk = 1:</b> the master is closed — it froze the value D had at the rising edge (${st.M}). The slave is open and shows it: <b>Q = ${st.S}</b>. Changing D now does nothing.`
        : `<b>clk = 0:</b> the master is open and follows D (${st.M}). The slave is closed, so <b>Q = ${st.S}</b> is held. Q only changes when clk goes 0 → 1.`;
    }
    update();
  }

  /* ================================================================ *
   *  Overview mini demo: Not vs DFF                                   *
   * ================================================================ */
  function makeOverview() {
    const dff = new H.Sim(H.BUILTINS.DFF);
    let x = 0;
    const lampNot = $('#ovNot'), lampDff = $('#ovDff');
    const sw = Switch('x', (v) => { x = v; dff.set('in', x); dff.eval(); paint(); });
    const clk = html('<button class="btn clk" type="button">⏱ Clock</button>');
    clk.addEventListener('click', () => { dff.cycle(); paint(); restartAnim(lampDff, 'flash'); });
    $('#ovCtrl').append(sw.el, clk);
    function paint() {
      sw.set(x);
      const n = x ? 0 : 1, q = dff.get('out');
      lampNot.textContent = n; lampNot.classList.toggle('on', !!n);
      lampDff.textContent = q; lampDff.classList.toggle('on', !!q);
    }
    paint();
  }

  /* ================================================================ *
   *  HDL Lab                                                          *
   * ================================================================ */
  const lab = {
    ready: false,
    chip: 'Bit',
    def: null,
    sim: null,
    view: null,
    ctrls: {},
    prev: {},
    ensure() { if (!this.ready) { this.init(); this.ready = true; } },

    init() {
      const ta = $('#labSrc');
      this.ta = ta;
      this.hl = $('#labHl');
      this.gut = $('#labGut');
      this.chip = store.get('sl-lab-chip', 'Bit');
      if (!SRC[this.chip]) this.chip = 'Bit';
      $('#labChip').value = this.chip;
      ta.value = store.get('sl-lab-' + this.chip, SRC[this.chip]);

      ta.addEventListener('input', () => { this.renderEditor(); store.set('sl-lab-' + this.chip, ta.value); });
      ta.addEventListener('scroll', () => this.sync());
      ta.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
          e.preventDefault();
          ta.setRangeText('    ', ta.selectionStart, ta.selectionEnd, 'end');
          ta.dispatchEvent(new Event('input'));
        }
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); this.compile(); }
      });
      $('#labChip').addEventListener('change', (e) => {
        this.chip = e.target.value;
        store.set('sl-lab-chip', this.chip);
        ta.value = store.get('sl-lab-' + this.chip, SRC[this.chip]);
        $('#labTests').innerHTML = '<div class="hint-line">Press “Run tests” to compare your chip with the reference.</div>';
        this.compile();
      });
      $('#labCompile').addEventListener('click', () => this.compile());
      $('#labTest').addEventListener('click', () => this.runTests());
      $('#labSolution').addEventListener('click', () => this.loadText(SRC[this.chip], 'Replace your code with the reference solution?'));
      $('#labBlank').addEventListener('click', () => this.loadText(SKEL[this.chip], 'Replace your code with an empty skeleton?'));
      $('#labDownload').addEventListener('click', () => {
        const blob = new Blob([ta.value], { type: 'text/plain' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `${this.chip}.hdl`;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
      });

      const clk = $('#labClock');
      clk.innerHTML = `
        <button class="btn" type="button" data-a="tick" title="Rising edge: clocked parts sample their inputs">↑ Tick</button>
        <button class="btn" type="button" data-a="tock" title="Outputs of clocked parts update">↓ Tock</button>
        <button class="btn clk" type="button" data-a="cycle">⏱ Clock (tick + tock)</button>
        <button class="btn ghost" type="button" data-a="reset">↺ Reset</button>`;
      clk.addEventListener('click', (e) => {
        const b = e.target.closest('[data-a]');
        if (!b || !this.sim) return;
        const a = b.dataset.a;
        try {
          if (a === 'tick') this.sim.tick();
          else if (a === 'tock') this.sim.tock();
          else if (a === 'cycle') this.sim.cycle();
          else this.sim.reset();
        } catch (err) { this.status('err', esc(err.message)); }
        this.refresh(a !== 'reset');
      });
      this.compile();
    },

    loadText(text, question) {
      if (this.ta.value !== text && this.ta.value !== SRC[this.chip] && this.ta.value !== SKEL[this.chip]) {
        if (!window.confirm(question)) return;
      }
      this.ta.value = text;
      store.set('sl-lab-' + this.chip, text);
      this.compile();
    },

    sync() {
      this.hl.scrollTop = this.ta.scrollTop;
      this.hl.scrollLeft = this.ta.scrollLeft;
      this.gut.scrollTop = this.ta.scrollTop;
    },

    renderEditor(errLine) {
      const src = this.ta.value;
      this.hl.innerHTML = renderLines(src, null, errLine) + '<div class="cl"> </div>';
      const n = src.split('\n').length;
      let g = '';
      for (let i = 1; i <= n + 1; i++) g += `<div${errLine === i ? ' class="err"' : ''}>${i <= n ? i : ''}</div>`;
      this.gut.innerHTML = g;
      this.sync();
    },

    status(kind, msg) {
      const s = $('#labStatus');
      s.className = 'status ' + (kind || '');
      s.innerHTML = msg;
    },

    compile() {
      const src = this.ta.value;
      try {
        const def = H.compile(src);
        this.def = def;
        this.sim = new H.Sim(def);
        this.sim.eval();
        this.prev = {};
        const what = def.builtin ? 'a built-in chip' : `${def.parts.length} part${def.parts.length === 1 ? '' : 's'}, ${def.internals.length} internal pin${def.internals.length === 1 ? '' : 's'}`;
        let msg = `✓ Compiled <b>${esc(def.name)}</b> — ${what}. Set the inputs and clock it, or run the tests.`;
        if (def.name !== this.chip) msg += `<div class="warn">Note: the chip is named ${esc(def.name)}, but the tests are for ${this.chip}.</div>`;
        (def.warnings || []).forEach((w) => { msg += `<div class="warn">⚠ ${esc(w)}</div>`; });
        this.status('ok', msg);
        this.renderEditor();
        this.buildPins();
        this.view = new CodeView($('#labLive'), def, this.sim);
        this.refresh(false);
      } catch (e) {
        this.def = null;
        this.sim = null;
        const line = e.line || 0;
        let msg = `<b>${line ? `Line ${line}` : 'Error'}:</b> ${esc(e.message)}`;
        if (e.all && e.all.length > 1) {
          msg += `<div class="more">${e.all.length - 1} more problem${e.all.length > 2 ? 's' : ''}:<br>${e.all.slice(1, 5).map((x) => `line ${x.line}: ${esc(x.message)}`).join('<br>')}</div>`;
        }
        this.status('err', msg);
        this.renderEditor(line);
        $('#labPins').innerHTML = '<div class="hint-line">Fix the error and compile again to simulate.</div>';
        $('#labLive').innerHTML = '';
        $('#labSignals').innerHTML = '';
        $('#labTime').textContent = '';
        if (line) {
          const top = (line - 4) * 20;
          this.ta.scrollTop = Math.max(0, top);
          this.sync();
        }
      }
    },

    buildPins() {
      const host = $('#labPins');
      host.innerHTML = '';
      const inRow = html('<div class="row"></div>');
      const outRow = html('<div class="row"></div>');
      this.ctrls = {};
      for (const p of this.def.inputs) {
        const on = (v) => { this.sim.set(p.name, v); this.sim.eval(); this.refresh(true); };
        const c = p.width === 1 ? Switch(p.name, on) : Word(p.name, p.width, on);
        this.ctrls[p.name] = c;
        inRow.appendChild(c.el);
      }
      this.outs = {};
      for (const p of this.def.outputs) {
        const el = html(`<div class="outbox"><div class="on">${esc(p.name)}${p.width > 1 ? `[${p.width}]` : ''}</div><div class="ov">0</div><div class="ob"></div></div>`);
        this.outs[p.name] = el;
        outRow.appendChild(el);
      }
      host.append(html('<div class="lbl-group" style="font:700 11px var(--mono);color:var(--dim);letter-spacing:.08em">IN</div>'), inRow,
        html('<div class="lbl-group" style="font:700 11px var(--mono);color:var(--dim);letter-spacing:.08em">OUT</div>'), outRow);
    },

    refresh(flash) {
      if (!this.sim) return;
      const sim = this.sim;
      for (const p of this.def.inputs) this.ctrls[p.name].set(sim.get(p.name));
      for (const p of this.def.outputs) {
        const v = sim.get(p.name), el = this.outs[p.name];
        el.querySelector('.ov').textContent = fmt(v, p.width);
        el.querySelector('.ob').textContent = p.width > 1 ? bin(v, p.width) : '';
        el.style.borderColor = p.width === 1 && v ? 'var(--hi)' : '';
      }
      if (this.view) this.view.update(flash);
      $('#labTime').textContent = `time: ${sim.time}${sim.half ? '+  (after tick, before tock)' : ''}`;
      const all = [];
      this.def.inputs.forEach((p) => all.push(['IN', p]));
      this.def.outputs.forEach((p) => all.push(['OUT', p]));
      (this.def.internals || []).forEach((p) => all.push(['internal', p]));
      let t = '<table class="pins"><thead><tr><th>kind</th><th>pin</th><th>value</th><th>binary</th></tr></thead><tbody>';
      for (const [k, p] of all) {
        const v = sim.get(p.name);
        const chg = flash && this.prev[p.name] !== undefined && this.prev[p.name] !== v;
        this.prev[p.name] = v;
        t += `<tr${chg ? ' class="chg"' : ''}><td>${k}</td><td>${esc(p.name)}${p.width > 1 ? `[${p.width}]` : ''}</td><td class="v">${fmt(v, p.width)}</td><td>${bin(v, p.width)}</td></tr>`;
      }
      $('#labSignals').innerHTML = t + '</tbody></table>';
    },

    runTests() {
      this.compile();
      if (!this.def) {
        $('#labTests').innerHTML = '<div class="test-sum fail">Fix the compile error first.</div>';
        return;
      }
      const r = H.runTests(this.def, this.chip);
      const host = $('#labTests');
      if (r.error && !(r.rows && r.rows.length)) {
        host.innerHTML = `<div class="test-sum fail">✗ ${esc(r.error)}</div>`;
        return;
      }
      const ins = r.inputs ? r.inputs : H.BUILTINS[this.chip].inputs;
      const outs = r.outputs ? r.outputs : H.BUILTINS[this.chip].outputs;
      let s = `<div class="test-sum ${r.ok ? 'pass' : 'fail'}"><span class="big">${r.passed} / ${r.total}</span>${r.ok ? '✓ All comparisons passed — your chip matches the reference.' : '✗ Some comparisons failed.'}</div>`;
      if (r.error) s += `<div class="status err">${esc(r.error)}</div>`;
      if (!r.ok && r.firstFail >= 0) {
        const f = r.rows[r.firstFail];
        s += `<p>First mismatch at <b>time ${f.time}</b> with ${ins.map((p) => `<code>${p.name}=${fmt(f.inputs[p.name], p.width)}</code>`).join(' ')}: expected ${outs.map((p) => `<code>${p.name}=${fmt(f.expected[p.name], p.width)}</code>`).join(' ')}, your chip gave ${outs.map((p) => `<code>${p.name}=${fmt(f.actual[p.name], p.width)}</code>`).join(' ')}.</p>`;
      }
      s += '<div class="test-table"><table><thead><tr><th>time</th>' + ins.map((p) => `<th>${p.name}</th>`).join('') +
        outs.map((p) => `<th>expected ${p.name}</th><th>your ${p.name}</th>`).join('') + '<th></th></tr></thead><tbody>';
      r.rows.forEach((row, i) => {
        s += `<tr${row.ok ? '' : ' class="bad"'} data-row="${i}"><td>${row.time}</td>` +
          ins.map((p) => `<td>${fmt(row.inputs[p.name], p.width)}</td>`).join('') +
          outs.map((p) => `<td>${fmt(row.expected[p.name], p.width)}</td><td>${fmt(row.actual[p.name], p.width)}</td>`).join('') +
          `<td class="${row.ok ? 'okc' : ''}">${row.ok ? '✓' : '✗'}</td></tr>`;
      });
      s += '</tbody></table></div>';
      host.innerHTML = s;
      if (!r.ok && r.firstFail >= 0) {
        const box = host.querySelector('.test-table');
        const tr = box.querySelector(`[data-row="${r.firstFail}"]`);
        if (tr) box.scrollTop = Math.max(0, tr.offsetTop - 60);
      }
    },
  };

  /* ================================================================ *
   *  Keyboard shortcuts                                               *
   * ================================================================ */
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
    const d = demos[currentTab];
    if (!d) return;
    const k = e.key.toLowerCase();
    if (k === 'c') { e.preventDefault(); d.clock(); }
    if (k === 'a') { e.preventDefault(); d.toggleAuto(); }
  });

  /* ================================================================ *
   *  Boot                                                             *
   * ================================================================ */
  function boot() {
    const safe = (fn, name) => { try { fn(); } catch (err) { console.error(`Failed to build ${name}:`, err); } };
    safe(makeOverview, 'overview');
    safe(makeDFF, 'DFF');
    safe(makeMasterSlave, 'master-slave');
    safe(makeBit, 'Bit');
    safe(makeRegister, 'Register');
    safe(makeRAM8, 'RAM8');
    safe(makePC, 'PC');
    showTab(location.hash.slice(1) || 'overview', false);
  }
  boot();
  window.SeqLogic = { demos, lab, showTab };
})();
