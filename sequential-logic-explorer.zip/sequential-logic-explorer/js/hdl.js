/*
 * hdl.js — a small Nand2Tetris-style HDL compiler and clocked simulator.
 * No dependencies. Exposes HDL on window (browser) or globalThis (Node).
 *
 *   const def = HDL.compile(sourceText);   // parse + check + link
 *   const sim = new HDL.Sim(def);
 *   sim.set('in', 1); sim.eval();          // combinational settle
 *   sim.tick(); sim.tock();                // one clock cycle
 *   sim.get('out');                        // any IN / OUT / internal pin
 */
(function (g) {
  'use strict';

  const mask = (w) => (w >= 31 ? 0x7fffffff : (1 << w) - 1);
  const s16 = (v) => (v & 0x8000 ? v - 0x10000 : v);

  class HDLError extends Error {
    constructor(message, line, col) {
      super(message);
      this.name = 'HDLError';
      this.line = line || 0;
      this.col = col || 0;
    }
  }

  /* ------------------------------------------------------------------ *
   *  Built-in chips                                                     *
   * ------------------------------------------------------------------ */
  function pinSpec(spec) {
    if (!spec) return [];
    return spec.split(',').map((s) => {
      const m = s.trim().match(/^(\w+)(?:\[(\d+)\])?$/);
      return { name: m[1], width: m[2] ? +m[2] : 1 };
    });
  }

  const BUILTINS = {};
  function builtin(name, ins, outs, make, clocked) {
    BUILTINS[name] = {
      name, builtin: true,
      inputs: pinSpec(ins), outputs: pinSpec(outs),
      internals: [], make, clocked: clocked || [],
    };
  }
  const comb = (fn) => () => ({ eval: fn });
  const letters = (n) => 'abcdefgh'.slice(0, n).split('');

  builtin('Nand', 'a,b', 'out', comb((i, o) => { o.out = i.a & i.b ? 0 : 1; }));
  builtin('Not', 'in', 'out', comb((i, o) => { o.out = i.in ? 0 : 1; }));
  builtin('And', 'a,b', 'out', comb((i, o) => { o.out = i.a & i.b; }));
  builtin('Or', 'a,b', 'out', comb((i, o) => { o.out = i.a | i.b; }));
  builtin('Xor', 'a,b', 'out', comb((i, o) => { o.out = i.a ^ i.b; }));
  builtin('Mux', 'a,b,sel', 'out', comb((i, o) => { o.out = i.sel ? i.b : i.a; }));
  builtin('DMux', 'in,sel', 'a,b', comb((i, o) => { o.a = i.sel ? 0 : i.in; o.b = i.sel ? i.in : 0; }));
  builtin('Not16', 'in[16]', 'out[16]', comb((i, o) => { o.out = ~i.in & 0xffff; }));
  builtin('And16', 'a[16],b[16]', 'out[16]', comb((i, o) => { o.out = i.a & i.b; }));
  builtin('Or16', 'a[16],b[16]', 'out[16]', comb((i, o) => { o.out = i.a | i.b; }));
  builtin('Mux16', 'a[16],b[16],sel', 'out[16]', comb((i, o) => { o.out = i.sel ? i.b : i.a; }));
  builtin('Or8Way', 'in[8]', 'out', comb((i, o) => { o.out = i.in ? 1 : 0; }));
  builtin('Mux4Way16', 'a[16],b[16],c[16],d[16],sel[2]', 'out[16]',
    comb((i, o) => { o.out = i[letters(4)[i.sel]]; }));
  builtin('Mux8Way16', 'a[16],b[16],c[16],d[16],e[16],f[16],g[16],h[16],sel[3]', 'out[16]',
    comb((i, o) => { o.out = i[letters(8)[i.sel]]; }));
  builtin('DMux4Way', 'in,sel[2]', 'a,b,c,d',
    comb((i, o) => { letters(4).forEach((k, n) => { o[k] = n === i.sel ? i.in : 0; }); }));
  builtin('DMux8Way', 'in,sel[3]', 'a,b,c,d,e,f,g,h',
    comb((i, o) => { letters(8).forEach((k, n) => { o[k] = n === i.sel ? i.in : 0; }); }));
  builtin('HalfAdder', 'a,b', 'sum,carry', comb((i, o) => { o.sum = i.a ^ i.b; o.carry = i.a & i.b; }));
  builtin('FullAdder', 'a,b,c', 'sum,carry', comb((i, o) => {
    const s = i.a + i.b + i.c; o.sum = s & 1; o.carry = s >> 1;
  }));
  builtin('Add16', 'a[16],b[16]', 'out[16]', comb((i, o) => { o.out = (i.a + i.b) & 0xffff; }));
  builtin('Inc16', 'in[16]', 'out[16]', comb((i, o) => { o.out = (i.in + 1) & 0xffff; }));
  builtin('ALU', 'x[16],y[16],zx,nx,zy,ny,f,no', 'out[16],zr,ng', comb((i, o) => {
    let x = i.x, y = i.y;
    if (i.zx) x = 0;
    if (i.nx) x = ~x & 0xffff;
    if (i.zy) y = 0;
    if (i.ny) y = ~y & 0xffff;
    let r = i.f ? (x + y) & 0xffff : x & y;
    if (i.no) r = ~r & 0xffff;
    o.out = r; o.zr = r === 0 ? 1 : 0; o.ng = (r >> 15) & 1;
  }));

  // ---- sequential (clocked) built-ins: tick = sample inputs, tock = commit ----
  function register(width, withLoad) {
    return () => {
      let s = 0, n = 0;
      return {
        eval(i, o) { o.out = s; },
        tick(i) { n = withLoad ? (i.load ? i.in : s) : i.in; n &= mask(width); },
        tock() { s = n; },
        reset() { s = n = 0; },
        peek: () => ({ state: s, next: n }),
      };
    };
  }
  builtin('DFF', 'in', 'out', register(1, false), ['in']);
  builtin('Bit', 'in,load', 'out', register(1, true), ['in', 'load']);
  builtin('Register', 'in[16],load', 'out[16]', register(16, true), ['in', 'load']);

  function ram(size) {
    return () => {
      const mem = new Array(size).fill(0);
      let pending = null;
      return {
        eval(i, o) { o.out = mem[i.address] || 0; },
        tick(i) { pending = i.load ? [i.address, i.in] : null; },
        tock() { if (pending) mem[pending[0]] = pending[1]; pending = null; },
        reset() { mem.fill(0); pending = null; },
        peek: () => ({ mem }),
      };
    };
  }
  builtin('RAM8', 'in[16],load,address[3]', 'out[16]', ram(8), ['in', 'load']);
  builtin('RAM64', 'in[16],load,address[6]', 'out[16]', ram(64), ['in', 'load']);

  builtin('PC', 'in[16],load,inc,reset', 'out[16]', () => {
    let s = 0, n = 0;
    return {
      eval(i, o) { o.out = s; },
      tick(i) { n = i.reset ? 0 : i.load ? i.in : i.inc ? (s + 1) & 0xffff : s; },
      tock() { s = n; },
      reset() { s = n = 0; },
      peek: () => ({ state: s, next: n }),
    };
  }, ['in', 'load', 'inc', 'reset']);

  /* ------------------------------------------------------------------ *
   *  Lexer / parser                                                     *
   * ------------------------------------------------------------------ */
  function tokenize(src) {
    const toks = [];
    let i = 0, line = 1, lineStart = 0;
    const n = src.length;
    while (i < n) {
      const c = src[i];
      if (c === '\n') { line++; i++; lineStart = i; continue; }
      if (c === ' ' || c === '\t' || c === '\r') { i++; continue; }
      if (c === '/' && src[i + 1] === '/') { while (i < n && src[i] !== '\n') i++; continue; }
      if (c === '/' && src[i + 1] === '*') {
        const j = src.indexOf('*/', i + 2);
        if (j < 0) throw new HDLError('Comment opened with /* is never closed with */', line, i - lineStart + 1);
        for (let k = i; k < j + 2; k++) if (src[k] === '\n') { line++; lineStart = k + 1; }
        i = j + 2;
        continue;
      }
      const start = i, col = i - lineStart + 1;
      if (/[A-Za-z_]/.test(c)) {
        while (i < n && /\w/.test(src[i])) i++;
        toks.push({ t: 'id', v: src.slice(start, i), line, col, start, end: i });
        continue;
      }
      if (/\d/.test(c)) {
        while (i < n && /\d/.test(src[i])) i++;
        toks.push({ t: 'num', v: +src.slice(start, i), line, col, start, end: i });
        continue;
      }
      if (c === '.' && src[i + 1] === '.') {
        i += 2;
        toks.push({ t: 'sym', v: '..', line, col, start, end: i });
        continue;
      }
      if ('{}()[],;=:'.includes(c)) {
        i++;
        toks.push({ t: 'sym', v: c, line, col, start, end: i });
        continue;
      }
      throw new HDLError(`Unexpected character "${c}"`, line, col);
    }
    toks.push({ t: 'eof', v: '', line, col: i - lineStart + 1, start: i, end: i });
    return toks;
  }

  function parse(src) {
    const toks = tokenize(src);
    let p = 0;
    const peek = () => toks[p];
    const next = () => toks[p++];
    const desc = (t) => (t.t === 'eof' ? 'the end of the file' : `"${t.v}"`);
    const fail = (msg, t = peek()) => { throw new HDLError(msg, t.line, t.col); };
    const expect = (v) => {
      const t = peek();
      if (t.v !== v || t.t === 'num') fail(`Expected "${v}" but found ${desc(t)}`);
      return next();
    };
    const ident = (what) => {
      const t = peek();
      if (t.t !== 'id') fail(`Expected ${what} but found ${desc(t)}`);
      return next();
    };
    const number = () => {
      const t = peek();
      if (t.t !== 'num') fail(`Expected a number but found ${desc(t)}`);
      return next().v;
    };
    const range = () => {
      expect('[');
      const lo = number();
      let hi = lo;
      if (peek().v === '..') { next(); hi = number(); }
      const close = expect(']');
      if (hi < lo) fail(`Sub-bus [${lo}..${hi}] is backwards; write the smaller index first`, close);
      return [lo, hi];
    };

    expect('CHIP');
    const nameTok = ident('a chip name');
    expect('{');
    const chip = { name: nameTok.v, inputs: [], outputs: [], parts: [], line: nameTok.line };
    const declared = new Set();
    const pinList = (arr) => {
      do {
        const t = ident('a pin name');
        let width = 1;
        if (peek().v === '[') {
          next();
          const wt = peek();
          width = number();
          expect(']');
          if (width < 1 || width > 16) fail('Bus width must be between 1 and 16', wt);
        }
        if (declared.has(t.v)) fail(`Pin "${t.v}" is declared twice`, t);
        declared.add(t.v);
        arr.push({ name: t.v, width, line: t.line });
      } while (peek().v === ',' && next());
      expect(';');
    };
    if (peek().v === 'IN') { next(); pinList(chip.inputs); }
    if (peek().v === 'OUT') { next(); pinList(chip.outputs); }

    if (peek().v === 'BUILTIN') {
      next();
      chip.builtin = ident('a chip name').v;
      expect(';');
      if (peek().v === 'CLOCKED') {
        next();
        do { ident('a pin name'); } while (peek().v === ',' && next());
        expect(';');
      }
      expect('}');
      return chip;
    }

    const partsTok = peek();
    if (partsTok.v !== 'PARTS') fail(`Expected "PARTS:" but found ${desc(partsTok)}`);
    next();
    expect(':');
    while (peek().v !== '}') {
      if (peek().t === 'eof') fail('Missing "}" at the end of the chip');
      const pt = ident('a part (chip name), e.g. "Mux(...)"');
      const part = { chip: pt.v, line: pt.line, col: pt.col, conns: [] };
      expect('(');
      if (peek().v !== ')') {
        do {
          const pinTok = ident('a pin name');
          const conn = { pin: pinTok.v, line: pinTok.line, col: pinTok.col };
          if (peek().v === '[') [conn.pinLo, conn.pinHi] = range();
          expect('=');
          const sTok = peek();
          if (sTok.t !== 'id') fail(`Expected a signal name (or true/false) after "${pinTok.v}=" but found ${desc(sTok)}`);
          next();
          conn.sig = sTok.v;
          conn.sigLine = sTok.line;
          conn.sigCol = sTok.col;
          conn.sigEnd = sTok.end;
          if (peek().v === '[') { [conn.sigLo, conn.sigHi] = range(); conn.sigEnd = toks[p - 1].end; }
          part.conns.push(conn);
        } while (peek().v === ',' && next());
      }
      const close = peek();
      if (close.v !== ')') fail(`Expected "," or ")" in ${pt.v}(...) but found ${desc(close)}`);
      next();
      if (peek().v !== ';') fail(`Missing ";" after ${pt.v}(...)`, close);
      next();
      chip.parts.push(part);
    }
    expect('}');
    if (peek().t !== 'eof') fail(`Unexpected ${desc(peek())} after the end of the chip`);
    return chip;
  }

  /* ------------------------------------------------------------------ *
   *  Compile = parse + check + link to chip definitions                 *
   * ------------------------------------------------------------------ */
  function editDistance(a, b) {
    const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j++) d[0][j] = j;
    for (let i = 1; i <= a.length; i++) {
      for (let j = 1; j <= b.length; j++) {
        d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      }
    }
    return d[a.length][b.length];
  }
  function suggest(word, list) {
    const lw = word.toLowerCase();
    const exact = list.find((x) => x.toLowerCase() === lw);
    if (exact) return exact;
    let best = null, bd = 3;
    for (const x of list) {
      const dd = editDistance(lw, x.toLowerCase());
      if (dd < bd) { bd = dd; best = x; }
    }
    return best;
  }
  const fmtPin = (p) => (p.width > 1 ? `${p.name}[${p.width}]` : p.name);

  function compile(src, lib) {
    lib = lib || BUILTINS;
    const ast = parse(src);
    if (ast.builtin) {
      const def = lib[ast.builtin];
      if (!def) throw new HDLError(`There is no built-in chip called "${ast.builtin}"`, ast.line, 1);
      return Object.assign({}, def, { source: src, ast });
    }

    const errors = [];
    const err = (msg, line, col) => errors.push(new HDLError(msg, line, col));
    const io = {};
    ast.inputs.forEach((x) => { io[x.name] = { kind: 'in', width: x.width }; });
    ast.outputs.forEach((x) => { io[x.name] = { kind: 'out', width: x.width }; });
    const internals = {};
    const parts = [];

    for (const part of ast.parts) {
      const def = lib[part.chip];
      if (!def) {
        const s = suggest(part.chip, Object.keys(lib));
        err(`Unknown chip "${part.chip}".${s ? ` Did you mean "${s}"?` : ''}`, part.line, part.col);
        continue;
      }
      const pinIndex = {};
      def.inputs.forEach((x) => { pinIndex[x.name] = { dir: 'in', width: x.width }; });
      def.outputs.forEach((x) => { pinIndex[x.name] = { dir: 'out', width: x.width }; });
      const P = { def, line: part.line, ins: [], outs: [] };
      const usedInBits = {};

      for (const c of part.conns) {
        const pi = pinIndex[c.pin];
        if (!pi) {
          const all = def.inputs.concat(def.outputs);
          err(`${def.name} has no pin called "${c.pin}". Its pins are: ${all.map(fmtPin).join(', ')}`, c.line, c.col);
          continue;
        }
        let lo = 0, hi = pi.width - 1;
        if (c.pinLo !== undefined) {
          if (c.pinHi >= pi.width) {
            err(`${c.pin}[${c.pinLo}${c.pinHi !== c.pinLo ? '..' + c.pinHi : ''}] is out of range: ${def.name}.${c.pin} is ${pi.width} bit(s) wide`, c.line, c.col);
            continue;
          }
          lo = c.pinLo; hi = c.pinHi;
        }
        const w = hi - lo + 1;
        const conn = { pin: c.pin, pinLo: lo, pinW: w, sig: c.sig, src: c };

        if (c.sig === 'true' || c.sig === 'false') {
          if (pi.dir === 'out') { err(`Output pin ${def.name}.${c.pin} can't be connected to the constant ${c.sig}`, c.line, c.col); continue; }
          conn.const = c.sig === 'true' ? mask(w) : 0;
          P.ins.push(conn);
          continue;
        }

        const ext = io[c.sig];
        let sLo = 0, sW;
        if (ext) {
          sW = ext.width;
          if (c.sigLo !== undefined) {
            if (c.sigHi >= ext.width) { err(`${c.sig}[${c.sigLo}..${c.sigHi}] is out of range: "${c.sig}" is ${ext.width} bit(s) wide`, c.sigLine, c.sigCol); continue; }
            sLo = c.sigLo; sW = c.sigHi - c.sigLo + 1;
          }
          if (sW !== w) {
            err(`Width mismatch: ${def.name}.${c.pin}${c.pinLo !== undefined ? `[${lo}..${hi}]` : ''} is ${w} bit(s) but "${c.sig}${c.sigLo !== undefined ? `[${c.sigLo}..${c.sigHi}]` : ''}" is ${sW}`, c.line, c.col);
            continue;
          }
        } else if (c.sigLo !== undefined) {
          err(`Internal pin "${c.sig}" can't be indexed with [..]. Only the chip's own IN/OUT pins can be sub-bussed.`, c.sigLine, c.sigCol);
          continue;
        }
        conn.sLo = sLo;

        if (pi.dir === 'in') {
          if (ext && ext.kind === 'out') {
            err(`"${c.sig}" is an OUT pin of ${ast.name}, and an OUT pin can't be fed back into a part. Give the part's output a second name instead, e.g. "out=${c.sig}, out=feedback", and use "feedback" here.`, c.sigLine, c.sigCol);
            continue;
          }
          const bits = mask(w) << lo;
          if ((usedInBits[c.pin] || 0) & bits) { err(`Input pin ${def.name}.${c.pin} is connected more than once`, c.line, c.col); continue; }
          usedInBits[c.pin] = (usedInBits[c.pin] || 0) | bits;
          if (ext) conn.sW = sW;
          else {
            conn.internal = true;
            (internals[c.sig] = internals[c.sig] || { width: null, uses: [] })
              .uses.push({ w, line: c.sigLine, col: c.sigCol, part: def.name, pin: c.pin });
          }
          P.ins.push(conn);
        } else {
          if (ext && ext.kind === 'in') { err(`Can't drive "${c.sig}": it is an IN pin of ${ast.name}`, c.sigLine, c.sigCol); continue; }
          if (ext) conn.sW = sW;
          else {
            const it = internals[c.sig] = internals[c.sig] || { width: null, uses: [] };
            if (it.width !== null) {
              err(`Internal pin "${c.sig}" already has a source (line ${it.srcLine}). Each internal pin can be driven by only one part output.`, c.sigLine, c.sigCol);
              continue;
            }
            it.width = w; it.srcLine = c.line;
            conn.internal = true; conn.sW = w;
          }
          P.outs.push(conn);
        }
      }
      parts.push(P);
    }

    for (const name of Object.keys(internals)) {
      const it = internals[name];
      if (it.width === null) {
        const u = it.uses[0];
        const s = suggest(name, Object.keys(internals).filter((k) => internals[k].width !== null).concat(Object.keys(io)));
        err(`"${name}" is used as an input, but no part produces it.${s ? ` Did you mean "${s}"?` : ` Add "out=${name}" to the part that should produce it.`}`, u.line, u.col);
        continue;
      }
      for (const u of it.uses) {
        if (u.w !== it.width) err(`Width mismatch: "${name}" is ${it.width} bit(s) wide but ${u.part}.${u.pin} expects ${u.w}`, u.line, u.col);
      }
    }
    for (const P of parts) for (const c of P.ins) if (c.internal) c.sW = internals[c.sig].width || c.pinW;

    // Combinational loops: a cycle of parts that is not broken by a clocked input.
    if (!errors.length) {
      const writer = {};
      parts.forEach((P, k) => P.outs.forEach((c) => { if (c.internal) writer[c.sig] = k; }));
      const adj = parts.map(() => []);
      parts.forEach((P, k) => {
        const clocked = new Set(P.def.clocked || []);
        P.ins.forEach((c) => {
          if (c.internal && !clocked.has(c.pin) && writer[c.sig] !== undefined) adj[writer[c.sig]].push(k);
        });
      });
      const color = parts.map(() => 0), stack = [];
      let cycle = null;
      const dfs = (u) => {
        color[u] = 1; stack.push(u);
        for (const v of adj[u]) {
          if (cycle) return;
          if (color[v] === 1) { cycle = stack.slice(stack.indexOf(v)).concat(v); return; }
          if (color[v] === 0) dfs(v);
        }
        stack.pop(); color[u] = 2;
      };
      for (let k = 0; k < parts.length && !cycle; k++) if (!color[k]) dfs(k);
      if (cycle) {
        const names = cycle.map((k) => `${parts[k].def.name} (line ${parts[k].line})`);
        err(`Combinational loop: ${names.join(' → ')}. A signal may only loop back through a clocked chip (DFF, Bit, Register…); otherwise it never settles.`, parts[cycle[0]].line, 1);
      }
    }

    const warnings = [];
    for (const o of ast.outputs) {
      let cov = 0;
      for (const P of parts) for (const c of P.outs) if (c.sig === o.name && !c.internal) cov |= mask(c.sW) << c.sLo;
      if (cov !== mask(o.width)) warnings.push(`OUT pin "${o.name}" is not fully driven by any part — those bits will always be 0.`);
    }

    if (errors.length) {
      errors.sort((a, b) => a.line - b.line);
      const e = errors[0];
      e.all = errors;
      throw e;
    }

    return {
      name: ast.name,
      builtin: false,
      inputs: ast.inputs.map((x) => ({ name: x.name, width: x.width })),
      outputs: ast.outputs.map((x) => ({ name: x.name, width: x.width })),
      internals: Object.keys(internals).map((k) => ({ name: k, width: internals[k].width })),
      parts, warnings, source: src, ast,
      clocked: [],
    };
  }

  /* ------------------------------------------------------------------ *
   *  Simulation                                                         *
   * ------------------------------------------------------------------ */
  function instantiate(def) { return def.builtin ? new BuiltinInst(def) : new CompositeInst(def); }

  class BuiltinInst {
    constructor(def) {
      this.def = def;
      this.impl = def.make();
      this.in = {}; this.out = {};
      def.inputs.forEach((p) => { this.in[p.name] = 0; });
      def.outputs.forEach((p) => { this.out[p.name] = 0; });
      this.eval();
    }
    eval() { this.impl.eval(this.in, this.out); }
    tick() { this.eval(); if (this.impl.tick) this.impl.tick(this.in); }
    tock() { if (this.impl.tock) this.impl.tock(); this.eval(); }
    reset() { if (this.impl.reset) this.impl.reset(); this.eval(); }
    get(name) { return (name in this.in ? this.in[name] : this.out[name]) || 0; }
    peek() { return this.impl.peek ? this.impl.peek() : {}; }
  }

  class CompositeInst {
    constructor(def) {
      this.def = def;
      this.sig = {}; this.in = {}; this.out = {};
      def.inputs.forEach((p) => { this.sig[p.name] = 0; this.in[p.name] = 0; });
      def.outputs.forEach((p) => { this.sig[p.name] = 0; this.out[p.name] = 0; });
      def.internals.forEach((p) => { this.sig[p.name] = 0; });
      this.parts = def.parts.map((P) => ({ P, inst: instantiate(P.def) }));
      this.maxIter = this.parts.length + 4;
      this.eval();
    }
    eval() {
      const sig = this.sig, def = this.def;
      for (const p of def.inputs) sig[p.name] = this.in[p.name] & mask(p.width);
      for (let iter = 0; ; iter++) {
        let changed = false;
        for (const { P, inst } of this.parts) {
          for (const p of P.def.inputs) inst.in[p.name] = 0;
          for (const c of P.ins) {
            const v = c.const !== undefined ? c.const : (sig[c.sig] >>> c.sLo) & mask(c.sW);
            inst.in[c.pin] |= (v & mask(c.pinW)) << c.pinLo;
          }
          inst.eval();
          for (const c of P.outs) {
            const v = (inst.out[c.pin] >>> c.pinLo) & mask(c.pinW);
            const old = sig[c.sig];
            const m = mask(c.sW) << c.sLo;
            const nv = (old & ~m) | ((v << c.sLo) & m);
            if (nv !== old) { sig[c.sig] = nv; changed = true; }
          }
        }
        if (!changed) break;
        if (iter > this.maxIter) throw new HDLError(`${def.name}: signals never settled (combinational loop?)`, 0, 0);
      }
      for (const p of def.outputs) this.out[p.name] = sig[p.name];
    }
    tick() { this.eval(); for (const { inst } of this.parts) inst.tick(); }
    tock() { for (const { inst } of this.parts) inst.tock(); this.eval(); }
    reset() {
      for (const k of Object.keys(this.sig)) this.sig[k] = 0;
      for (const { inst } of this.parts) inst.reset();
      this.eval();
    }
    get(name) { return this.sig[name] || 0; }
  }

  class Sim {
    constructor(def) {
      this.def = def;
      this.inst = instantiate(def);
      this.time = 0;
      this.half = false;
      this.widths = {};
      this.kinds = {};
      def.inputs.forEach((p) => { this.widths[p.name] = p.width; this.kinds[p.name] = 'in'; });
      def.outputs.forEach((p) => { this.widths[p.name] = p.width; this.kinds[p.name] = 'out'; });
      (def.internals || []).forEach((p) => { this.widths[p.name] = p.width; this.kinds[p.name] = 'internal'; });
    }
    set(name, v) {
      if (!(name in this.widths) || this.kinds[name] !== 'in') throw new Error(`No input pin "${name}"`);
      this.inst.in[name] = v & mask(this.widths[name]);
    }
    get(name) { return this.inst.get(name); }
    width(name) { return this.widths[name] || 1; }
    eval() { this.inst.eval(); }
    tick() { if (!this.half) { this.inst.tick(); this.half = true; } }
    tock() { if (!this.half) this.inst.tick(); this.inst.tock(); this.half = false; this.time++; }
    cycle() { this.tick(); this.tock(); }
    reset() { this.inst.reset(); this.time = 0; this.half = false; }
  }

  /* ------------------------------------------------------------------ *
   *  Tests: compare a chip against the built-in reference               *
   * ------------------------------------------------------------------ */
  function lcg(seed) {
    let s = seed >>> 0;
    return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
  }
  const rint = (r, n) => Math.floor(r() * n);

  const PLANS = {
    Bit() {
      const r = lcg(7);
      const st = [[0, 0], [0, 1], [1, 0], [1, 1], [0, 0], [1, 0], [0, 0], [1, 1], [0, 0], [0, 1],
        [1, 0], [0, 0], [1, 0], [0, 1], [1, 1], [1, 0], [0, 0]].map(([i, l]) => ({ in: i, load: l }));
      for (let k = 0; k < 30; k++) st.push({ in: r() < 0.5 ? 1 : 0, load: r() < 0.4 ? 1 : 0 });
      return st;
    },
    Register() {
      const r = lcg(11);
      const st = [];
      [0, -32123, 11111, -1, 32767, -32768, 1, 21845, -21846, 12345, 256, 4096].forEach((v) => {
        st.push({ in: v, load: 0 }, { in: v, load: 1 }, { in: ~v, load: 0 });
      });
      for (let k = 0; k < 30; k++) st.push({ in: rint(r, 65536), load: r() < 0.5 ? 1 : 0 });
      return st;
    },
    RAM8() {
      const r = lcg(5);
      const st = [];
      for (let a = 0; a < 8; a++) st.push({ address: a, in: (a + 1) * 1111 * (a % 2 ? -1 : 1), load: 1 });
      for (let a = 0; a < 8; a++) st.push({ address: a, in: 4321, load: 0 });
      for (let k = 0; k < 40; k++) st.push({ address: rint(r, 8), in: rint(r, 65536), load: r() < 0.45 ? 1 : 0 });
      return st;
    },
    RAM64() {
      const r = lcg(9);
      const st = [];
      for (let a = 0; a < 64; a += 9) st.push({ address: a, in: a * 1000 + 7, load: 1 });
      for (let a = 0; a < 64; a += 9) st.push({ address: a, in: 1, load: 0 });
      for (let k = 0; k < 60; k++) st.push({ address: rint(r, 64), in: rint(r, 65536), load: r() < 0.5 ? 1 : 0 });
      return st;
    },
    PC() {
      const r = lcg(3);
      const st = [{ in: 0, reset: 0, load: 0, inc: 0 }, { inc: 1 }, {}, { in: -32123 }, { load: 1 }, { load: 0 }, {},
        { in: 12345, load: 1, inc: 0 }, { reset: 1 }, { reset: 0, inc: 1 }, { reset: 1 }, { reset: 0, load: 0, inc: 0 },
        { load: 1, in: 2, inc: 1 }, { reset: 1, load: 1 }, { reset: 0, load: 0, inc: 1 }, { in: -1, load: 1 },
        { load: 0 }, {}, { inc: 0 }, { inc: 1, in: 22222, reset: 1 }, { reset: 0 }];
      for (let k = 0; k < 40; k++) {
        st.push({ in: rint(r, 65536), reset: r() < 0.15 ? 1 : 0, load: r() < 0.3 ? 1 : 0, inc: r() < 0.7 ? 1 : 0 });
      }
      return st;
    },
  };

  function interfaceString(def) {
    return `IN ${def.inputs.map(fmtPin).join(', ')}; OUT ${def.outputs.map(fmtPin).join(', ')};`;
  }

  function runTests(def, refName) {
    const ref = BUILTINS[refName];
    const plan = PLANS[refName];
    if (!ref || !plan) return { ok: false, error: `No tests available for ${refName}` };
    if (interfaceString(def) !== interfaceString(ref)) {
      return { ok: false, error: `The interface doesn't match ${refName}. Expected: ${interfaceString(ref)}  Found: ${interfaceString(def)}` };
    }
    const A = new Sim(def), B = new Sim(ref);
    const ins = ref.inputs.map((p) => p.name), outs = ref.outputs.map((p) => p.name);
    const rows = [];
    let passed = 0, firstFail = -1;
    const current = {};
    ins.forEach((k) => { current[k] = 0; });
    try {
      for (const step of plan()) {
        Object.assign(current, step);
        for (const k of ins) { A.set(k, current[k]); B.set(k, current[k]); }
        A.eval(); B.eval();
        for (const phase of ['tick', 'tock']) {
          if (phase === 'tick') { A.tick(); B.tick(); } else { A.tock(); B.tock(); }
          const time = phase === 'tick' ? `${B.time}+` : `${B.time}`;
          const row = { time, inputs: {}, expected: {}, actual: {}, ok: true };
          ins.forEach((k) => { row.inputs[k] = B.get(k); });
          outs.forEach((k) => {
            row.expected[k] = B.get(k); row.actual[k] = A.get(k);
            if (row.expected[k] !== row.actual[k]) row.ok = false;
          });
          if (row.ok) passed++; else if (firstFail < 0) firstFail = rows.length;
          rows.push(row);
        }
      }
    } catch (e) {
      return { ok: false, error: e.message, rows, passed, total: rows.length, firstFail };
    }
    return { ok: firstFail < 0, rows, passed, total: rows.length, firstFail, inputs: ref.inputs, outputs: ref.outputs };
  }

  /* ------------------------------------------------------------------ *
   *  Syntax highlighting lexer (never throws)                           *
   * ------------------------------------------------------------------ */
  const KW = new Set(['CHIP', 'IN', 'OUT', 'PARTS', 'BUILTIN', 'CLOCKED']);
  function lex(src) {
    const out = [];
    let i = 0, prevSym = '', mode = '';
    const n = src.length;
    while (i < n) {
      const c = src[i], s = i;
      if (c === '/' && src[i + 1] === '/') { while (i < n && src[i] !== '\n') i++; out.push({ cls: 'c', s, e: i }); continue; }
      if (c === '/' && src[i + 1] === '*') { const j = src.indexOf('*/', i + 2); i = j < 0 ? n : j + 2; out.push({ cls: 'c', s, e: i }); continue; }
      if (/\s/.test(c)) { while (i < n && /\s/.test(src[i])) i++; out.push({ cls: '', s, e: i }); continue; }
      if (/[A-Za-z_]/.test(c)) {
        while (i < n && /\w/.test(src[i])) i++;
        const w = src.slice(s, i);
        let cls = 'i';
        if (KW.has(w)) { cls = 'k'; mode = w === 'IN' || w === 'OUT' ? 'io' : w === 'CHIP' ? 'chip' : w === 'BUILTIN' ? 'chip' : ''; }
        else if (w === 'true' || w === 'false') cls = 'b';
        else if (mode === 'io') cls = 'io';
        else if (mode === 'chip') { cls = 'cn'; mode = ''; }
        else if (prevSym === '=') cls = 'sg';
        else {
          let j = i;
          while (j < n && /[ \t]/.test(src[j])) j++;
          if (src[j] === '(') cls = 'f';
          else {
            if (src[j] === '[') { const k = src.indexOf(']', j); j = k < 0 ? n : k + 1; while (j < n && /[ \t]/.test(src[j])) j++; }
            if (src[j] === '=') cls = 'pn';
          }
        }
        out.push({ cls, s, e: i });
        prevSym = '';
        continue;
      }
      if (/\d/.test(c)) { while (i < n && /\d/.test(src[i])) i++; out.push({ cls: 'n', s, e: i }); continue; }
      if (c === '.' && src[i + 1] === '.') i += 2; else i++;
      const sym = src.slice(s, i);
      if (sym === ';') mode = '';
      if (sym !== '[' && sym !== ']' && sym !== '..') prevSym = sym;
      out.push({ cls: 'p', s, e: i });
    }
    return out;
  }

  g.HDL = { compile, parse, Sim, BUILTINS, HDLError, runTests, lex, mask, s16, interfaceString, fmtPin };
})(typeof window !== 'undefined' ? window : globalThis);
