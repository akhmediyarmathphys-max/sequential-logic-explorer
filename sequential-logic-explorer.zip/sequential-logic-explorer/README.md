# Sequential Logic Explorer — DFF, Bit, Register, RAM8, PC

An interactive, offline website that explains the Nand2Tetris sequential chips (Chapter 3 / Project 3)
and runs their HDL live in the browser.

## How to open
Unzip, then double-click **index.html**. No server or internet needed
(fonts load from Google Fonts when online; system fonts are used otherwise).

## What's inside
| Page | What you can do |
|---|---|
| Overview | Combinational vs sequential mini-demo, the clock, the chip hierarchy |
| DFF | out(t) = in(t-1); live DFF, timing diagram, master–slave latch explainer |
| Bit | Mux + DFF + feedback circuit that lights up; active row of the truth table |
| Register | 16 Bits sharing one load; click bits, see two's-complement values |
| RAM8 | DMux8Way write path + Mux8Way16 read path; click a register to address it |
| PC | Inc16 + 3 × Mux16 + Register; priority reset > load > inc, highlighted route |
| HDL Lab | Edit HDL, compile (Ctrl+Enter), tick/tock, see all signals, run automatic tests |

Every chip page has: **Clock** (C), **Auto** (A), random inputs, reset, the running HDL with live
value badges on every wire, "Right now" / "Last clock edge" explanations, a prediction quiz and a
timing diagram.

## Files
- `index.html` — page structure and explanations
- `css/style.css` — styles (dark/light theme)
- `js/hdl.js` — a small Nand2Tetris-style HDL compiler + clocked simulator + test runner
- `js/chips.js` — reference HDL sources and blank skeletons
- `js/app.js` — circuits, waveforms, interactions, HDL Lab
- `hdl/*.hdl` — the reference solutions as plain files

## The HDL engine
Supports `CHIP`, `IN`/`OUT` buses, `PARTS:`, sub-buses (`in[0..7]`), `true`/`false`, multiple
outputs (`out=out, out=feedback`) and `BUILTIN`. Built-in parts: Nand, Not, And, Or, Xor, Mux, DMux,
Not16, And16, Or16, Mux16, Or8Way, Mux4Way16, Mux8Way16, DMux4Way, DMux8Way, HalfAdder, FullAdder,
Add16, Inc16, ALU, DFF, Bit, Register, RAM8, RAM64, PC.
It reports friendly errors: unknown chips/pins (with "did you mean"), width mismatches, reading an OUT
pin, undriven internal pins, and combinational loops that don't pass through a clocked chip.
